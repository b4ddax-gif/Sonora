# SONORA — Premium Android Music Streaming & Offline Player

SONORA is a high-performance, modern music streaming and offline audio player built with Kotlin, Jetpack Compose, Material 3, and AndroidX Media3 (ExoPlayer). Designed for Android 10 (API 29) through Android 16 (API 36), SONORA delivers an immersive AMOLED dark listening experience with zero compromise on audio fidelity, legal compliance, or battery efficiency.

---

## Key Highlights

- **Obsidian Dark Aesthetic**: Custom-crafted Material 3 dark color scheme engineered for high contrast, minimal eye fatigue, and optimal battery savings on OLED/AMOLED screens.
- **Media3 & ExoPlayer Audio Engine**: Background playback managed via `MediaSessionService` (`PlaybackService`) with system notification media controls, lock screen metadata, lock screen scrubbing, headset button support, and audio focus management (ducking during calls and pause on noisy unplug).
- **Offline & Local Audio Support**:
  - Download licensed/authorized tracks to encrypted internal storage.
  - Scan and import user-owned local audio files from device storage (`.mp3`, `.m4a`, `.wav`, `.flac`, `.aac`, `.ogg`).
  - Storage management dashboard with real-time byte calculation and one-tap cache/downloads cleanup.
- **Strict Legal & Copyright Guardrails**: Built-in URL validation strictly blocks ripping, extracting, or downloading from YouTube or unauthorized third-party platforms.
- **Intelligent Gemini AI Curator**: Integrated neural recommendation engine powered by Google Gemini 3.5 Flash for context-aware playlist generation, mood matching, and listener analysis with instant local fallback.
- **Room Database Architecture**: Local persistence for songs, albums, artists, custom playlists, favorite tracks, recently played history, and offline file records.

---

## Architecture Overview

SONORA adheres to Google's official **MVVM (Model-View-ViewModel)** and **Clean Architecture** guidelines:

```
app/src/main/java/com/example/
├── data/
│   ├── local/                     # Room Database & DAOs
│   │   ├── AppDatabase.kt         # Database instance & type converters
│   │   └── dao/MusicDaos.kt       # Song, Album, Artist, Playlist, Favorite, Download DAOs
│   ├── model/                     # Data classes & Entity converters
│   │   └── MusicModels.kt
│   ├── preferences/               # Persistent User Settings (DataStore / Preferences)
│   │   └── SonoraSettings.kt
│   ├── repository/                # Single Source of Truth
│   │   ├── MusicRepository.kt     # Repository interface & implementation
│   │   ├── DownloadRepository.kt  # Authorized offline downloads & storage management
│   │   ├── LocalMusicScanner.kt   # Device MediaStore audio file scanner
│   │   └── GeminiRecommendationRepository.kt # AI-driven vibe curation
│   └── sample/                    # High-fidelity sample licensed music catalog
│       └── SampleMusicData.kt
├── playback/
│   ├── MusicPlayerManager.kt      # ExoPlayer controller & reactive StateFlows
│   └── PlaybackService.kt         # AndroidX MediaSessionService foreground service
└── ui/
    ├── components/                # Modular Compose Components
    │   ├── MusicCard.kt           # Horizontal scrolling music cards
    │   ├── SongItemRow.kt         # Song row with interactive popup options menu
    │   ├── MiniPlayer.kt          # Persistent bottom playback strip with progress line
    │   ├── FullScreenPlayer.kt    # Expanding player sheet with waveform & queue
    │   ├── QueueBottomSheet.kt    # Reorderable playback queue modal
    │   └── PlaylistDialogs.kt     # Create & Add-to-Playlist dialogs
    ├── screens/                   # Destination Screens
    │   ├── home/                  # Feed, Recently Played, Trending, Playlists
    │   ├── search/                # Debounced search across songs, artists, albums
    │   ├── library/               # Playlists, Liked Songs, Downloads, Local Audio
    │   ├── playlist/              # Playlist details, track management, reorder
    │   ├── gemini/                # Neural AI prompt assistant & mood playlists
    │   └── settings/              # Audio quality, Wi-Fi only, theme, guardrails
    ├── theme/                     # Sonora Design System (Obsidian & Electric Coral)
    └── SonoraMainScreen.kt        # NavHostController & Bottom Navigation Scaffold
```

---

## Legal Policy & Authorized Audio Compliance

### Strict Prohibition Against YouTube Downloading / Ripping
SONORA strictly enforces policies preventing the scraping, conversion, extraction, caching, or downloading of audio or video from YouTube or any other third-party platform in violation of its terms:
- `DownloadRepository.isYouTubeUrl()` intercepts and rejects all YouTube domains (`youtube.com`, `youtu.be`, `music.youtube.com`).
- The application displays the clear advisory:
  > *"Direct downloading from YouTube isn't supported. You can use authorized audio sources or import music you have permission to use."*
- Offline downloads function **exclusively** for tracks authorized by licensed music catalogs, creative commons/public domain repositories, or user-owned audio files.

---

## Required Android Permissions

The app requests the minimum permissions required for core audio functionality:

| Permission | Protection Level | Purpose |
|---|---|---|
| `android.permission.INTERNET` | Normal (Install-time) | Streaming authorized audio and fetching Gemini AI recommendations |
| `android.permission.FOREGROUND_SERVICE` | Normal (Install-time) | Maintaining background playback when app is minimized |
| `android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK` | Normal (Android 14+) | System media notification, lock-screen controls, and ExoPlayer service |
| `android.permission.POST_NOTIFICATIONS` | Runtime (Android 13+) | Showing player playback controls in notification drawer |
| `android.permission.READ_MEDIA_AUDIO` | Runtime (Android 13+) | Scanning and importing user-owned audio files on device |
| `android.permission.READ_EXTERNAL_STORAGE` | Runtime (Android 10-12) | Fallback for local storage scanning on older Android versions |

---

## Setup & Build Guide

### Prerequisites
- Android Studio Ladybug (2024.2+) or newer
- JDK 17 or JDK 21
- Android SDK 36 (targetSdk 36, minSdk 29)

### Running the App
1. Open the project in Google AI Studio or Android Studio.
2. Ensure dependencies are synced via Gradle:
   ```bash
   gradle assembleDebug
   ```
3. Run on a connected device or emulator running Android 10 through 16:
   ```bash
   gradle installDebug
   ```

### Optional: Configuring Gemini API Key
SONORA includes an intelligent local fallback recommendation engine that functions without any API keys. For live Gemini 3.5 Flash neural curation:
1. Obtain an API key from [Google AI Studio](https://aistudio.google.com/).
2. In the app, navigate to **Settings > Gemini API Configuration** and paste your key, or configure it securely in your `.env` build config.

---

## Features Walkthrough

1. **Home Screen**:
   - Header with Sonora logo and quick shortcuts to Settings and AI Curator.
   - Recently Played carousel with progress resumes.
   - Horizontal music cards for trending licensed tracks.
   - Curated playlists and featured artists.
2. **Music Player**:
   - Compact Mini Player docked above bottom navigation with smooth progress bar.
   - Expanding Full-Screen Player with high-res artwork, waveform visualizer, audio format badge, repeat/shuffle toggles, and live playback scrub slider.
   - Up-Next Queue sheet with drag/tap play and queue clear options.
3. **Instant Search**:
   - 250ms debounced instant search.
   - Dynamic filter chips (`All`, `Songs`, `Artists`, `Playlists`).
   - Recent searches history with one-tap clearing.
4. **Library & Playlists**:
   - Tabs for Playlists, Liked Songs, Downloads, Local Audio, Albums, and Artists.
   - Create, rename, and delete custom playlists.
   - Add any streaming or local track to personal playlists.
5. **Offline Downloads & Local Storage**:
   - Download licensed songs with single tap.
   - Storage usage meter displaying exact megabytes used.
   - Local device audio scanner (`LocalMusicScanner`) utilizing Android's `MediaStore.Audio.Media`.
6. **Audio Preferences**:
   - Streaming quality selection: Normal (128 kbps), High (320 kbps), Lossless FLAC.
   - Wi-Fi only download constraint to conserve mobile data.
   - Cache and search history cleaner.
