package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.SonoraMainScreen
import com.example.ui.theme.SonoraTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val app = SonoraApplication.instance
            val themeMode by app.settings.themeMode.collectAsState()

            SonoraTheme(themePreference = themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SonoraMainScreen(app = app)
                }
            }
        }
    }
}
