package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.SonoraApplication
import kotlinx.coroutines.launch
import com.example.ui.components.FullScreenPlayerDialog
import com.example.ui.components.MiniPlayer
import com.example.ui.screens.gemini.GeminiAssistantScreen
import com.example.ui.screens.gemini.GeminiViewModel
import com.example.ui.screens.gemini.GeminiViewModelFactory
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.home.HomeViewModel
import com.example.ui.screens.home.HomeViewModelFactory
import com.example.ui.screens.library.LibraryScreen
import com.example.ui.screens.library.LibraryViewModel
import com.example.ui.screens.library.LibraryViewModelFactory
import com.example.ui.screens.playlist.PlaylistDetailScreen
import com.example.ui.screens.playlist.PlaylistDetailViewModel
import com.example.ui.screens.playlist.PlaylistDetailViewModelFactory
import com.example.ui.screens.search.SearchScreen
import com.example.ui.screens.search.SearchViewModel
import com.example.ui.screens.search.SearchViewModelFactory
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.settings.SettingsViewModel
import com.example.ui.screens.settings.SettingsViewModelFactory
import com.example.ui.theme.SonoraDarkBackground
import com.example.ui.theme.SonoraDarkSurface
import com.example.ui.theme.SonoraPrimary
import com.example.ui.theme.SonoraTextMuted

object SonoraRoutes {
    const val HOME = "home"
    const val SEARCH = "search"
    const val LIBRARY = "library"
    const val PLAYLIST_DETAIL = "playlist/{playlistId}"
    const val GEMINI = "gemini"
    const val SETTINGS = "settings"

    fun playlistDetail(playlistId: String) = "playlist/$playlistId"
}

@Composable
fun SonoraMainScreen(
    app: SonoraApplication = SonoraApplication.instance,
    navController: NavHostController = rememberNavController()
) {
    val coroutineScope = androidx.compose.runtime.rememberCoroutineScope()
    val playerManager = app.playerManager
    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()
    val isLoading by playerManager.isLoading.collectAsState()
    val currentPositionMs by playerManager.currentPositionMs.collectAsState()
    val durationMs by playerManager.durationMs.collectAsState()
    val queue by playerManager.queue.collectAsState()
    val currentIndex by playerManager.currentIndex.collectAsState()
    val isShuffle by playerManager.isShuffleEnabled.collectAsState()
    val repeatMode by playerManager.repeatMode.collectAsState()
    val playbackError by playerManager.playbackError.collectAsState()

    var showFullScreenPlayer by remember { mutableStateOf(false) }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val isTopLevelDestination = currentRoute in listOf(
        SonoraRoutes.HOME,
        SonoraRoutes.SEARCH,
        SonoraRoutes.LIBRARY
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = SonoraDarkBackground,
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                // Mini Player (Only show if a song is loaded or queued)
                if (currentSong != null) {
                    MiniPlayer(
                        song = currentSong,
                        isPlaying = isPlaying,
                        isLoading = isLoading,
                        currentPositionMs = currentPositionMs,
                        durationMs = durationMs,
                        onPlayPauseClick = { playerManager.togglePlayPause() },
                        onNextClick = { playerManager.skipToNext() },
                        onClick = { showFullScreenPlayer = true },
                        modifier = Modifier.padding(bottom = if (isTopLevelDestination) 0.dp else 8.dp)
                    )
                }

                // Bottom Navigation Bar (Shown on top-level tabs)
                if (isTopLevelDestination) {
                    NavigationBar(
                        containerColor = SonoraDarkSurface,
                        tonalElevation = 8.dp
                    ) {
                        NavigationBarItem(
                            selected = currentRoute == SonoraRoutes.HOME,
                            onClick = {
                                navController.navigate(SonoraRoutes.HOME) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (currentRoute == SonoraRoutes.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                                    contentDescription = "Home"
                                )
                            },
                            label = { Text("Home") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SonoraPrimary,
                                selectedTextColor = SonoraPrimary,
                                unselectedIconColor = SonoraTextMuted,
                                unselectedTextColor = SonoraTextMuted,
                                indicatorColor = Color.Transparent
                            ),
                            modifier = Modifier.testTag("nav_home")
                        )

                        NavigationBarItem(
                            selected = currentRoute == SonoraRoutes.SEARCH,
                            onClick = {
                                navController.navigate(SonoraRoutes.SEARCH) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (currentRoute == SonoraRoutes.SEARCH) Icons.Filled.Search else Icons.Outlined.Search,
                                    contentDescription = "Search"
                                )
                            },
                            label = { Text("Search") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SonoraPrimary,
                                selectedTextColor = SonoraPrimary,
                                unselectedIconColor = SonoraTextMuted,
                                unselectedTextColor = SonoraTextMuted,
                                indicatorColor = Color.Transparent
                            ),
                            modifier = Modifier.testTag("nav_search")
                        )

                        NavigationBarItem(
                            selected = currentRoute == SonoraRoutes.LIBRARY,
                            onClick = {
                                navController.navigate(SonoraRoutes.LIBRARY) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (currentRoute == SonoraRoutes.LIBRARY) Icons.Filled.LibraryMusic else Icons.Outlined.LibraryMusic,
                                    contentDescription = "Library"
                                )
                            },
                            label = { Text("Library") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SonoraPrimary,
                                selectedTextColor = SonoraPrimary,
                                unselectedIconColor = SonoraTextMuted,
                                unselectedTextColor = SonoraTextMuted,
                                indicatorColor = Color.Transparent
                            ),
                            modifier = Modifier.testTag("nav_library")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = SonoraRoutes.HOME
            ) {
                // Home Screen
                composable(SonoraRoutes.HOME) {
                    val homeViewModel: HomeViewModel = viewModel(
                        factory = HomeViewModelFactory(
                            app.musicRepository,
                            app.downloadRepository,
                            app.playerManager
                        )
                    )
                    HomeScreen(
                        viewModel = homeViewModel,
                        currentlyPlayingSong = currentSong,
                        onNavigateToPlaylist = { playlistId ->
                            navController.navigate(SonoraRoutes.playlistDetail(playlistId))
                        },
                        onNavigateToGemini = {
                            navController.navigate(SonoraRoutes.GEMINI)
                        },
                        onNavigateToSettings = {
                            navController.navigate(SonoraRoutes.SETTINGS)
                        }
                    )
                }

                // Search Screen
                composable(SonoraRoutes.SEARCH) {
                    val searchViewModel: SearchViewModel = viewModel(
                        factory = SearchViewModelFactory(
                            app.musicRepository,
                            app.downloadRepository,
                            app.settings,
                            app.playerManager
                        )
                    )
                    SearchScreen(
                        viewModel = searchViewModel,
                        currentlyPlayingSong = currentSong,
                        onNavigateToPlaylist = { playlistId ->
                            navController.navigate(SonoraRoutes.playlistDetail(playlistId))
                        }
                    )
                }

                // Library Screen
                composable(SonoraRoutes.LIBRARY) {
                    val libraryViewModel: LibraryViewModel = viewModel(
                        factory = LibraryViewModelFactory(
                            app.musicRepository,
                            app.downloadRepository,
                            app.localMusicScanner,
                            app.playerManager
                        )
                    )
                    LibraryScreen(
                        viewModel = libraryViewModel,
                        currentlyPlayingSong = currentSong,
                        onNavigateToPlaylist = { playlistId ->
                            navController.navigate(SonoraRoutes.playlistDetail(playlistId))
                        }
                    )
                }

                // Playlist Detail Screen
                composable(
                    route = SonoraRoutes.PLAYLIST_DETAIL,
                    arguments = listOf(navArgument("playlistId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val playlistId = backStackEntry.arguments?.getString("playlistId") ?: ""
                    val playlistViewModel: PlaylistDetailViewModel = viewModel(
                        factory = PlaylistDetailViewModelFactory(
                            playlistId,
                            app.musicRepository,
                            app.downloadRepository,
                            app.playerManager
                        )
                    )
                    PlaylistDetailScreen(
                        viewModel = playlistViewModel,
                        currentlyPlayingSong = currentSong,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }

                // Gemini Assistant Screen
                composable(SonoraRoutes.GEMINI) {
                    val geminiViewModel: GeminiViewModel = viewModel(
                        factory = GeminiViewModelFactory(
                            app.geminiRepository,
                            app.musicRepository,
                            app.downloadRepository,
                            app.playerManager
                        )
                    )
                    GeminiAssistantScreen(
                        viewModel = geminiViewModel,
                        currentlyPlayingSong = currentSong,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }

                // Settings Screen
                composable(SonoraRoutes.SETTINGS) {
                    val settingsViewModel: SettingsViewModel = viewModel(
                        factory = SettingsViewModelFactory(
                            app.settings,
                            app.downloadRepository,
                            app.geminiRepository
                        )
                    )
                    SettingsScreen(
                        viewModel = settingsViewModel,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }

            // Full-Screen Music Player Dialog
            FullScreenPlayerDialog(
                visible = showFullScreenPlayer,
                song = currentSong,
                isPlaying = isPlaying,
                isLoading = isLoading,
                currentPositionMs = currentPositionMs,
                durationMs = durationMs,
                queue = queue,
                currentIndex = currentIndex,
                isShuffle = isShuffle,
                repeatMode = repeatMode,
                errorMessage = playbackError,
                onPlayPause = { playerManager.togglePlayPause() },
                onNext = { playerManager.skipToNext() },
                onPrevious = { playerManager.skipToPrevious() },
                onSeek = { playerManager.seekTo(it) },
                onToggleShuffle = { playerManager.toggleShuffle() },
                onToggleRepeat = { playerManager.toggleRepeatMode() },
                onToggleFavorite = { songId ->
                    coroutineScope.launch {
                        app.musicRepository.toggleFavorite(songId)
                    }
                },
                onDownloadSong = { song ->
                    coroutineScope.launch {
                        app.downloadRepository.startDownload(song)
                    }
                },
                onQueueSelect = { playerManager.playFromQueue(it) },
                onRemoveFromQueue = { playerManager.removeFromQueue(it) },
                onClearQueue = { playerManager.clearQueue() },
                onRetryPlayback = { playerManager.retryPlayback() },
                onDismiss = { showFullScreenPlayer = false }
            )
        }
    }
}
