package com.example.ui.screens.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.Playlist
import com.example.data.model.Song
import com.example.data.repository.DownloadRepository
import com.example.data.repository.LocalMusicScanner
import com.example.data.repository.MusicRepository
import com.example.playback.MusicPlayerManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LibraryUiState(
    val selectedTab: Int = 0, // 0: Playlists, 1: Favorites, 2: Downloads, 3: Local, 4: Albums, 5: Artists
    val playlists: List<Playlist> = emptyList(),
    val favoriteSongs: List<Song> = emptyList(),
    val downloadedSongs: List<Song> = emptyList(),
    val localSongs: List<Song> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val storageUsageBytes: Long = 0L,
    val isScanning: Boolean = false,
    val scanMessage: String? = null
)

class LibraryViewModel(
    private val musicRepository: MusicRepository,
    private val downloadRepository: DownloadRepository,
    private val localMusicScanner: LocalMusicScanner,
    private val playerManager: MusicPlayerManager
) : ViewModel() {

    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    private val _scanMessage = MutableStateFlow<String?>(null)

    private data class LibSongsBundle(
        val playlists: List<Playlist>,
        val favorites: List<Song>,
        val downloads: List<Song>,
        val locals: List<Song>
    )

    private val songsAndPlaylistsFlow = combine(
        musicRepository.getAllPlaylists(),
        musicRepository.getFavorites(),
        musicRepository.getDownloadedSongs(),
        musicRepository.getLocalSongs()
    ) { playlists, favorites, downloads, locals ->
        LibSongsBundle(playlists, favorites, downloads, locals)
    }

    private val albumsAndArtistsFlow = combine(
        musicRepository.getAllAlbums(),
        musicRepository.getAllArtists()
    ) { albums, artists ->
        Pair(albums, artists)
    }

    val uiState: StateFlow<LibraryUiState> = combine(
        _selectedTab,
        songsAndPlaylistsFlow,
        albumsAndArtistsFlow,
        _isScanning,
        _scanMessage
    ) { tab, bundle, albumsArtists, isScanning, scanMsg ->
        LibraryUiState(
            selectedTab = tab,
            playlists = bundle.playlists,
            favoriteSongs = bundle.favorites,
            downloadedSongs = bundle.downloads,
            localSongs = bundle.locals,
            albums = albumsArtists.first,
            artists = albumsArtists.second,
            storageUsageBytes = downloadRepository.getStorageUsageBytes(),
            isScanning = isScanning,
            scanMessage = scanMsg
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LibraryUiState()
    )

    fun selectTab(index: Int) {
        _selectedTab.value = index
    }

    fun playSong(song: Song, queue: List<Song>) {
        playerManager.playSong(song, queue)
    }

    fun playAll(songs: List<Song>) {
        if (songs.isNotEmpty()) {
            playerManager.playQueue(songs, 0)
        }
    }

    fun toggleFavorite(songId: String) {
        viewModelScope.launch {
            musicRepository.toggleFavorite(songId)
        }
    }

    fun createPlaylist(title: String, description: String = "") {
        viewModelScope.launch {
            musicRepository.createPlaylist(title, description)
        }
    }

    fun deletePlaylist(playlistId: String) {
        viewModelScope.launch {
            musicRepository.deletePlaylist(playlistId)
        }
    }

    fun deleteDownload(songId: String) {
        viewModelScope.launch {
            downloadRepository.deleteDownload(songId)
        }
    }

    fun clearAllDownloads() {
        viewModelScope.launch {
            downloadRepository.clearAllDownloads()
        }
    }

    fun onSongsImported(songs: List<Song>) {
        viewModelScope.launch {
            if (songs.isNotEmpty()) {
                musicRepository.importLocalSongs(songs)
                _scanMessage.value = "Imported ${songs.size} local tracks successfully."
            } else {
                _scanMessage.value = "No compatible audio files found on device storage."
            }
        }
    }

    fun scanDeviceAudio() {
        viewModelScope.launch {
            _isScanning.value = true
            try {
                val scanned = localMusicScanner.scanDeviceAudio()
                if (scanned.isNotEmpty()) {
                    musicRepository.importLocalSongs(scanned)
                    _scanMessage.value = "Imported ${scanned.size} local tracks successfully."
                } else {
                    _scanMessage.value = "No compatible audio files found on device storage."
                }
            } catch (e: Exception) {
                _scanMessage.value = "Error scanning audio: ${e.message}"
            } finally {
                _isScanning.value = false
            }
        }
    }

    fun clearScanMessage() {
        _scanMessage.value = null
    }

    fun addToQueue(song: Song) {
        playerManager.addToQueue(song)
    }

    fun downloadSong(song: Song) {
        viewModelScope.launch {
            downloadRepository.startDownload(song)
        }
    }

    fun addToPlaylist(playlistId: String, songId: String) {
        viewModelScope.launch {
            musicRepository.addSongToPlaylist(playlistId, songId)
        }
    }
}

class LibraryViewModelFactory(
    private val musicRepository: MusicRepository,
    private val downloadRepository: DownloadRepository,
    private val localMusicScanner: LocalMusicScanner,
    private val playerManager: MusicPlayerManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return LibraryViewModel(musicRepository, downloadRepository, localMusicScanner, playerManager) as T
    }
}
