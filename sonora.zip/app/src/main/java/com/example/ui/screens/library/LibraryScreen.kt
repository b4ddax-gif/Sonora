package com.example.ui.screens.library

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Song
import com.example.ui.components.AddToPlaylistDialog
import com.example.ui.components.CreatePlaylistDialog
import com.example.ui.components.SongItemRow
import com.example.ui.theme.SonoraDarkSurfaceElevated
import com.example.ui.theme.SonoraDarkSurfaceVariant
import com.example.ui.theme.SonoraPrimary
import com.example.ui.theme.SonoraSecondary
import com.example.ui.theme.SonoraTextMuted
import com.example.ui.theme.SonoraTextSecondary
import com.example.ui.util.AudioScanState
import com.example.ui.util.FormatUtils
import com.example.ui.util.LocalAudioScannerHelper
import com.example.ui.util.rememberAudioScanLauncher

@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    currentlyPlayingSong: Song?,
    onNavigateToPlaylist: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var songForPlaylistDialog by remember { mutableStateOf<Song?>(null) }
    var playlistToDelete by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    // Media Audio permission & storage scanner helper
    val audioScanHelper = rememberAudioScanLauncher { songs ->
        viewModel.onSongsImported(songs)
    }

    LaunchedEffect(uiState.scanMessage) {
        uiState.scanMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearScanMessage()
        }
    }

    val tabs = listOf("Playlists", "Favorites", "Downloads", "Local Audio", "Albums", "Artists")

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Your Library",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )

                if (uiState.selectedTab == 0) {
                    IconButton(
                        onClick = { showCreatePlaylistDialog = true },
                        modifier = Modifier.testTag("create_playlist_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Create Playlist",
                            tint = SonoraPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }

            // Scrollable Tabs
            ScrollableTabRow(
                selectedTabIndex = uiState.selectedTab,
                edgePadding = 20.dp,
                containerColor = Color.Transparent,
                contentColor = SonoraPrimary,
                divider = {}
            ) {
                tabs.forEachIndexed { index, tabTitle ->
                    Tab(
                        selected = uiState.selectedTab == index,
                        onClick = { viewModel.selectTab(index) },
                        text = {
                            Text(
                                text = tabTitle,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = if (uiState.selectedTab == index) FontWeight.Bold else FontWeight.Normal
                                )
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Tab Content
            when (uiState.selectedTab) {
                // 0: PLAYLISTS
                0 -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 90.dp, start = 16.dp, end = 16.dp)
                    ) {
                        item {
                            // Create Playlist Row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { showCreatePlaylistDialog = true }
                                    .padding(vertical = 12.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(SonoraDarkSurfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "New Playlist",
                                        tint = SonoraPrimary,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(
                                        text = "Create Playlist",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                    Text(
                                        text = "Build your custom music collection",
                                        style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary)
                                    )
                                }
                            }
                        }

                        items(uiState.playlists) { playlist ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onNavigateToPlaylist(playlist.id) }
                                    .padding(vertical = 8.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AsyncImage(
                                    model = playlist.artworkUrl,
                                    contentDescription = playlist.title,
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = playlist.title,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = playlist.description.ifEmpty { "Curated collection" },
                                        style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }

                // 1: FAVORITES
                1 -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 90.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${uiState.favoriteSongs.size} Favorite Songs",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = SonoraTextSecondary)
                                )

                                if (uiState.favoriteSongs.isNotEmpty()) {
                                    Button(
                                        onClick = { viewModel.playAll(uiState.favoriteSongs) },
                                        colors = ButtonDefaults.buttonColors(containerColor = SonoraPrimary),
                                        shape = RoundedCornerShape(20.dp)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Play All")
                                    }
                                }
                            }
                        }

                        if (uiState.favoriteSongs.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 80.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.Favorite,
                                            contentDescription = null,
                                            tint = SonoraTextMuted,
                                            modifier = Modifier.size(54.dp)
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = "No favorites yet",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                                        )
                                        Text(
                                            text = "Tap the heart icon on any song to add it here.",
                                            style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary),
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                    }
                                }
                            }
                        } else {
                            items(uiState.favoriteSongs) { song ->
                                SongItemRow(
                                    song = song,
                                    isPlaying = currentlyPlayingSong?.id == song.id,
                                    onClick = { viewModel.playSong(song, uiState.favoriteSongs) },
                                    onToggleFavorite = { viewModel.toggleFavorite(song.id) },
                                    onAddToQueue = { viewModel.addToQueue(song) },
                                    onAddToPlaylist = { songForPlaylistDialog = song },
                                    onDownload = { viewModel.downloadSong(song) },
                                    onDeleteDownload = { viewModel.deleteDownload(song.id) },
                                    modifier = Modifier.padding(horizontal = 12.dp)
                                )
                            }
                        }
                    }
                }

                // 2: DOWNLOADS
                2 -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 90.dp)
                    ) {
                        item {
                            // Storage Usage Card
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp, vertical = 10.dp),
                                colors = CardDefaults.cardColors(containerColor = SonoraDarkSurfaceVariant),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Storage,
                                            contentDescription = "Storage",
                                            tint = SonoraSecondary,
                                            modifier = Modifier.size(28.dp)
                                        )
                                        Spacer(modifier = Modifier.width(14.dp))
                                        Column {
                                            Text(
                                                text = "Storage Used",
                                                style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary)
                                            )
                                            Text(
                                                text = FormatUtils.formatFileSize(uiState.storageUsageBytes),
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                            )
                                        }
                                    }

                                    if (uiState.downloadedSongs.isNotEmpty()) {
                                        TextButton(onClick = { viewModel.clearAllDownloads() }) {
                                            Text("Clear All", color = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }

                        if (uiState.downloadedSongs.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 60.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.DownloadDone,
                                            contentDescription = null,
                                            tint = SonoraTextMuted,
                                            modifier = Modifier.size(54.dp)
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = "No downloaded tracks yet",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                                        )
                                        Text(
                                            text = "Download authorized songs to listen without internet.",
                                            style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary),
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                    }
                                }
                            }
                        } else {
                            items(uiState.downloadedSongs) { song ->
                                SongItemRow(
                                    song = song,
                                    isPlaying = currentlyPlayingSong?.id == song.id,
                                    onClick = { viewModel.playSong(song, uiState.downloadedSongs) },
                                    onToggleFavorite = { viewModel.toggleFavorite(song.id) },
                                    onAddToQueue = { viewModel.addToQueue(song) },
                                    onAddToPlaylist = { songForPlaylistDialog = song },
                                    onDownload = {},
                                    onDeleteDownload = { viewModel.deleteDownload(song.id) },
                                    modifier = Modifier.padding(horizontal = 12.dp)
                                )
                            }
                        }
                    }
                }

                // 3: LOCAL AUDIO
                3 -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 90.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp, vertical = 10.dp),
                                colors = CardDefaults.cardColors(containerColor = SonoraDarkSurfaceVariant),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "Device Audio Files",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Import user-owned music files stored on your Android device.",
                                        style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary),
                                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                                    )

                                    Button(
                                        onClick = { audioScanHelper.startScan() },
                                        colors = ButtonDefaults.buttonColors(containerColor = SonoraPrimary),
                                        shape = RoundedCornerShape(20.dp),
                                        enabled = !audioScanHelper.isScanning && !uiState.isScanning
                                    ) {
                                        if (audioScanHelper.isScanning || uiState.isScanning) {
                                            CircularProgressIndicator(
                                                color = Color.White,
                                                modifier = Modifier.size(18.dp),
                                                strokeWidth = 2.dp
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Scanning device audio...")
                                        } else {
                                            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Scan Device Audio")
                                        }
                                    }
                                }
                            }
                        }

                        if (uiState.localSongs.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 40.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No local audio files imported yet.",
                                        style = MaterialTheme.typography.bodyMedium.copy(color = SonoraTextMuted)
                                    )
                                }
                            }
                        } else {
                            items(uiState.localSongs) { song ->
                                SongItemRow(
                                    song = song,
                                    isPlaying = currentlyPlayingSong?.id == song.id,
                                    onClick = { viewModel.playSong(song, uiState.localSongs) },
                                    onToggleFavorite = { viewModel.toggleFavorite(song.id) },
                                    onAddToQueue = { viewModel.addToQueue(song) },
                                    onAddToPlaylist = { songForPlaylistDialog = song },
                                    onDownload = {},
                                    onDeleteDownload = {},
                                    modifier = Modifier.padding(horizontal = 12.dp)
                                )
                            }
                        }
                    }
                }

                // 4: ALBUMS
                4 -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 90.dp, start = 16.dp, end = 16.dp)
                    ) {
                        items(uiState.albums) { album ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { /* preview or play album */ }
                                    .padding(vertical = 8.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AsyncImage(
                                    model = album.artworkUrl,
                                    contentDescription = album.title,
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(10.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = album.title,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                    Text(
                                        text = "${album.artist} • ${album.year} • ${album.songCount} tracks",
                                        style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary)
                                    )
                                }
                            }
                        }
                    }
                }

                // 5: ARTISTS
                5 -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 90.dp, start = 16.dp, end = 16.dp)
                    ) {
                        items(uiState.artists) { artist ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AsyncImage(
                                    model = artist.artworkUrl,
                                    contentDescription = artist.name,
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = artist.name,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                    Text(
                                        text = artist.genre,
                                        style = MaterialTheme.typography.bodySmall.copy(color = SonoraPrimary)
                                    )
                                    Text(
                                        text = artist.bio,
                                        style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary),
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }

    if (showCreatePlaylistDialog) {
        CreatePlaylistDialog(
            onDismiss = { showCreatePlaylistDialog = false },
            onCreate = { title ->
                viewModel.createPlaylist(title)
                showCreatePlaylistDialog = false
            }
        )
    }

    songForPlaylistDialog?.let { song ->
        AddToPlaylistDialog(
            song = song,
            playlists = uiState.playlists,
            onDismiss = { songForPlaylistDialog = null },
            onPlaylistSelected = { playlistId ->
                viewModel.addToPlaylist(playlistId, song.id)
            },
            onCreateNewPlaylist = { title ->
                viewModel.createPlaylist(title)
            }
        )
    }

    val scanState = audioScanHelper.state
    if (scanState is AudioScanState.PermissionDenied) {
        AlertDialog(
            onDismissRequest = { audioScanHelper.resetState() },
            title = { Text("Storage Permission Required") },
            text = {
                Text(
                    text = if (scanState.isPermanent) {
                        "${scanState.rationale}\n\nPlease open App Settings and grant the Audio permission to scan music on your device."
                    } else {
                        scanState.rationale
                    }
                )
            },
            confirmButton = {
                if (scanState.isPermanent) {
                    Button(onClick = {
                        audioScanHelper.openSettings()
                        audioScanHelper.resetState()
                    }) {
                        Text("Open Settings")
                    }
                } else {
                    Button(onClick = {
                        audioScanHelper.resetState()
                        audioScanHelper.startScan()
                    }) {
                        Text("Grant Permission")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { audioScanHelper.resetState() }) {
                    Text("Dismiss")
                }
            }
        )
    }
}
