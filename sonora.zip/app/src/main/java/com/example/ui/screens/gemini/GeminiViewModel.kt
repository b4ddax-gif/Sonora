package com.example.ui.screens.gemini

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Song
import com.example.data.repository.DownloadRepository
import com.example.data.repository.GeminiRecommendationRepository
import com.example.data.repository.MusicRepository
import com.example.data.repository.RecommendationResult
import com.example.playback.MusicPlayerManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class GeminiUiState(
    val selectedMood: String = "Deep Focus",
    val promptInput: String = "",
    val isGenerating: Boolean = false,
    val recommendationResult: RecommendationResult? = null,
    val recommendedSongs: List<Song> = emptyList(),
    val hasApiKey: Boolean = false,
    val successMessage: String? = null,
    val errorMessage: String? = null
)

class GeminiViewModel(
    private val geminiRepository: GeminiRecommendationRepository,
    private val musicRepository: MusicRepository,
    private val downloadRepository: DownloadRepository,
    private val playerManager: MusicPlayerManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        GeminiUiState(hasApiKey = geminiRepository.hasApiKey())
    )
    val uiState: StateFlow<GeminiUiState> = _uiState.asStateFlow()

    init {
        // Run initial recommendation for Deep Focus
        onSelectMood("Deep Focus")
    }

    fun onPromptChange(newPrompt: String) {
        _uiState.value = _uiState.value.copy(promptInput = newPrompt)
    }

    fun onSelectMood(mood: String) {
        _uiState.value = _uiState.value.copy(selectedMood = mood, promptInput = "")
        generateRecommendations(mood)
    }

    fun submitCustomPrompt() {
        val query = _uiState.value.promptInput.trim()
        if (query.isNotBlank()) {
            generateRecommendations(query)
        }
    }

    private fun generateRecommendations(prompt: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isGenerating = true,
                errorMessage = null,
                successMessage = null
            )

            try {
                val allSongs = musicRepository.getAllSongs().firstOrNull() ?: emptyList()
                val recent = musicRepository.getRecentlyPlayed().firstOrNull() ?: emptyList()

                val result = geminiRepository.getRecommendations(prompt, allSongs, recent)
                val matchedSongs = result.suggestedTrackIds.mapNotNull { id ->
                    allSongs.find { it.id == id }
                }

                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    recommendationResult = result,
                    recommendedSongs = matchedSongs,
                    hasApiKey = geminiRepository.hasApiKey()
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isGenerating = false,
                    errorMessage = "Failed to generate recommendations: ${e.message}"
                )
            }
        }
    }

    fun playVibe() {
        val songs = _uiState.value.recommendedSongs
        if (songs.isNotEmpty()) {
            playerManager.playQueue(songs, 0)
        }
    }

    fun playSong(song: Song) {
        playerManager.playSong(song, _uiState.value.recommendedSongs)
    }

    fun toggleFavorite(songId: String) {
        viewModelScope.launch {
            musicRepository.toggleFavorite(songId)
        }
    }

    fun addToQueue(song: Song) {
        playerManager.addToQueue(song)
    }

    fun downloadSong(song: Song) {
        viewModelScope.launch {
            downloadRepository.startDownload(song)
        }
    }

    fun deleteDownload(songId: String) {
        viewModelScope.launch {
            downloadRepository.deleteDownload(songId)
        }
    }

    fun saveAsPlaylist() {
        val songs = _uiState.value.recommendedSongs
        val result = _uiState.value.recommendationResult ?: return
        if (songs.isEmpty()) return

        viewModelScope.launch {
            val playlistId = musicRepository.createPlaylist(
                title = result.moodTitle,
                description = "AI curated vibe: ${result.explanation}"
            )
            songs.forEach { song ->
                musicRepository.addSongToPlaylist(playlistId, song.id)
            }
            _uiState.value = _uiState.value.copy(
                successMessage = "Saved \"${result.moodTitle}\" to your Playlists!"
            )
        }
    }

    fun clearSuccessMessage() {
        _uiState.value = _uiState.value.copy(successMessage = null)
    }
}

class GeminiViewModelFactory(
    private val geminiRepository: GeminiRecommendationRepository,
    private val musicRepository: MusicRepository,
    private val downloadRepository: DownloadRepository,
    private val playerManager: MusicPlayerManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return GeminiViewModel(geminiRepository, musicRepository, downloadRepository, playerManager) as T
    }
}
