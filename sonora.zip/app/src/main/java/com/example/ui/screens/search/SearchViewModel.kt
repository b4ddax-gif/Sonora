package com.example.ui.screens.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.Playlist
import com.example.data.model.Song
import com.example.data.preferences.SonoraSettings
import com.example.data.repository.DownloadRepository
import com.example.data.repository.MusicRepository
import com.example.playback.MusicPlayerManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SearchUiState(
    val query: String = "",
    val selectedFilter: String = "All", // "All", "Songs", "Artists", "Playlists"
    val songs: List<Song> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val recentSearches: List<String> = emptyList(),
    val isSearching: Boolean = false
)

class SearchViewModel(
    private val musicRepository: MusicRepository,
    private val downloadRepository: DownloadRepository,
    private val settings: SonoraSettings,
    private val playerManager: MusicPlayerManager
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _selectedFilter = MutableStateFlow("All")
    val selectedFilter: StateFlow<String> = _selectedFilter.asStateFlow()

    private val allMetadataFlow = combine(
        musicRepository.getAllAlbums(),
        musicRepository.getAllArtists(),
        musicRepository.getAllPlaylists()
    ) { albums, artists, playlists ->
        Triple(albums, artists, playlists)
    }

    @OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
    private val searchSongsFlow = _query.debounce(250).distinctUntilChanged().flatMapLatest { q ->
        if (q.isBlank()) flowOf(emptyList()) else musicRepository.search(q)
    }

    val uiState: StateFlow<SearchUiState> = combine(
        _query,
        _selectedFilter,
        settings.searchHistory,
        searchSongsFlow,
        allMetadataFlow
    ) { query, filter, history, searchSongs, (allAlbums, allArtists, allPlaylists) ->
        val filteredAlbums = if (query.isNotBlank()) {
            allAlbums.filter { it.title.contains(query, ignoreCase = true) || it.artist.contains(query, ignoreCase = true) }
        } else emptyList()

        val filteredArtists = if (query.isNotBlank()) {
            allArtists.filter { it.name.contains(query, ignoreCase = true) || it.genre.contains(query, ignoreCase = true) }
        } else emptyList()

        val filteredPlaylists = if (query.isNotBlank()) {
            allPlaylists.filter { it.title.contains(query, ignoreCase = true) || it.description.contains(query, ignoreCase = true) }
        } else emptyList()

        SearchUiState(
            query = query,
            selectedFilter = filter,
            songs = searchSongs,
            albums = filteredAlbums,
            artists = filteredArtists,
            playlists = filteredPlaylists,
            recentSearches = history,
            isSearching = query.isNotBlank()
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SearchUiState()
    )

    fun onQueryChange(newQuery: String) {
        _query.value = newQuery
    }

    fun onSearchSubmitted(submittedQuery: String) {
        if (submittedQuery.isNotBlank()) {
            settings.addSearchQuery(submittedQuery)
        }
    }

    fun onFilterSelected(filter: String) {
        _selectedFilter.value = filter
    }

    fun removeRecentSearch(item: String) {
        settings.removeSearchQuery(item)
    }

    fun clearSearchHistory() {
        settings.clearSearchHistory()
    }

    fun playSong(song: Song, queue: List<Song>) {
        if (_query.value.isNotBlank()) {
            settings.addSearchQuery(_query.value)
        }
        playerManager.playSong(song, queue)
    }

    fun toggleFavorite(songId: String) {
        viewModelScope.launch {
            musicRepository.toggleFavorite(songId)
        }
    }

    fun addToQueue(song: Song) {
        playerManager.addToQueue(song)
    }

    fun downloadSong(song: Song) {
        viewModelScope.launch {
            downloadRepository.startDownload(song)
        }
    }

    fun deleteDownload(songId: String) {
        viewModelScope.launch {
            downloadRepository.deleteDownload(songId)
        }
    }

    fun addToPlaylist(playlistId: String, songId: String) {
        viewModelScope.launch {
            musicRepository.addSongToPlaylist(playlistId, songId)
        }
    }

    fun createPlaylistAndAddSong(title: String, songId: String) {
        viewModelScope.launch {
            val id = musicRepository.createPlaylist(title)
            musicRepository.addSongToPlaylist(id, songId)
        }
    }
}

class SearchViewModelFactory(
    private val musicRepository: MusicRepository,
    private val downloadRepository: DownloadRepository,
    private val settings: SonoraSettings,
    private val playerManager: MusicPlayerManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return SearchViewModel(musicRepository, downloadRepository, settings, playerManager) as T
    }
}
