package com.example.ui.screens.gemini

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Song
import com.example.ui.components.SongItemRow
import com.example.ui.theme.SonoraDarkSurfaceElevated
import com.example.ui.theme.SonoraDarkSurfaceVariant
import com.example.ui.theme.SonoraPrimary
import com.example.ui.theme.SonoraSecondary
import com.example.ui.theme.SonoraTextMuted
import com.example.ui.theme.SonoraTextSecondary

@Composable
fun GeminiAssistantScreen(
    viewModel: GeminiViewModel,
    currentlyPlayingSong: Song?,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.successMessage) {
        uiState.successMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearSuccessMessage()
        }
    }

    val moodPresets = listOf(
        "All Indian Melodies",
        "Deep Focus",
        "Late Night Drive",
        "Bollywood & Sufi",
        "Sunset Acoustic",
        "Cosmic Ambient"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(start = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(SonoraPrimary, SonoraSecondary)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "SONORA AI CURATOR",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                // AI Status & Mode Banner
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = if (uiState.hasApiKey) SonoraPrimary.copy(alpha = 0.12f) else SonoraDarkSurfaceVariant
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (uiState.hasApiKey) Icons.Default.AutoAwesome else Icons.Default.Psychology,
                                contentDescription = null,
                                tint = if (uiState.hasApiKey) SonoraPrimary else SonoraSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (uiState.hasApiKey)
                                    "Powered by live Gemini 3.5 Flash neural curation"
                                else
                                    "Intelligent music engine active (Add Gemini key in Settings for live cloud curation)",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = if (uiState.hasApiKey) SonoraPrimary else SonoraTextSecondary,
                                    fontSize = 12.sp
                                )
                            )
                        }
                    }
                }

                // Prompt Input Box
                item {
                    Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
                        Text(
                            text = "Describe your mood, activity, or sound preference:",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = uiState.promptInput,
                            onValueChange = { viewModel.onPromptChange(it) },
                            placeholder = { Text("e.g., Coding late at night, rainy cafe, upbeat electronic...") },
                            trailingIcon = {
                                IconButton(
                                    onClick = { viewModel.submitCustomPrompt() },
                                    enabled = uiState.promptInput.isNotBlank() && !uiState.isGenerating
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Send,
                                        contentDescription = "Submit prompt",
                                        tint = if (uiState.promptInput.isNotBlank()) SonoraPrimary else SonoraTextMuted
                                    )
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = SonoraDarkSurfaceVariant,
                                unfocusedContainerColor = SonoraDarkSurfaceVariant,
                                focusedBorderColor = SonoraPrimary,
                                unfocusedBorderColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("gemini_prompt_input")
                        )
                    }
                }

                // Quick Mood Selector Chips
                item {
                    Column(modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)) {
                        Text(
                            text = "Quick Vibes",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SonoraTextMuted,
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                        )

                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 20.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(moodPresets) { mood ->
                                val selected = uiState.selectedMood == mood && uiState.promptInput.isBlank()
                                FilterChip(
                                    selected = selected,
                                    onClick = { viewModel.onSelectMood(mood) },
                                    label = { Text(mood) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = SonoraPrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }

                // Loading State
                if (uiState.isGenerating) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = SonoraPrimary)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = "Sonora AI is analyzing musical vibes...",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = SonoraTextSecondary)
                                )
                            }
                        }
                    }
                } else if (uiState.recommendationResult != null) {
                    val result = uiState.recommendationResult!!

                    // Recommendation Result Card
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 8.dp),
                            colors = CardDefaults.cardColors(containerColor = SonoraDarkSurfaceElevated),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = result.moodTitle,
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = SonoraPrimary
                                        )
                                    )

                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = SonoraPrimary.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = if (result.isLiveAi) "GEMINI 3.5" else "LOCAL ENGINE",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = SonoraPrimary,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            ),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = result.explanation,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onSurface,
                                        lineHeight = 20.sp
                                    ),
                                    modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = { viewModel.playVibe() },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = SonoraPrimary),
                                        shape = RoundedCornerShape(20.dp)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Play Vibe")
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.saveAsPlaylist() },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(20.dp)
                                    ) {
                                        Icon(Icons.Default.BookmarkBorder, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Save Playlist")
                                    }
                                }
                            }
                        }
                    }

                    // Recommended Songs List
                    item {
                        Text(
                            text = "Recommended Tracks (${uiState.recommendedSongs.size})",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
                        )
                    }

                    items(uiState.recommendedSongs) { song ->
                        SongItemRow(
                            song = song,
                            isPlaying = currentlyPlayingSong?.id == song.id,
                            onClick = { viewModel.playSong(song) },
                            onToggleFavorite = { viewModel.toggleFavorite(song.id) },
                            onAddToQueue = { viewModel.addToQueue(song) },
                            onAddToPlaylist = {},
                            onDownload = { viewModel.downloadSong(song) },
                            onDeleteDownload = { viewModel.deleteDownload(song.id) },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}
