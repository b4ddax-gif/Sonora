package com.example.ui.util

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.data.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * State representing the lifecycle of scanning local storage for audio files.
 */
sealed class AudioScanState {
    object Idle : AudioScanState()
    object RequestingPermission : AudioScanState()
    data class Scanning(val message: String = "Scanning storage for audio files...") : AudioScanState()
    data class Success(val songs: List<Song>, val count: Int) : AudioScanState()
    data class PermissionDenied(val isPermanent: Boolean, val rationale: String) : AudioScanState()
    data class Error(val message: String) : AudioScanState()
}

/**
 * Modern helper utility for scanning local storage audio files while handling
 * Android 10 through Android 16 permissions (READ_MEDIA_AUDIO on API 33+, READ_EXTERNAL_STORAGE on API 29-32).
 */
object LocalAudioScannerHelper {

    /**
     * Determines the appropriate permission string based on the Android OS version.
     * On Android 13 (Tiramisu, API 33) and above, returns Manifest.permission.READ_MEDIA_AUDIO.
     * On Android 10-12 (API 29-32), returns Manifest.permission.READ_EXTERNAL_STORAGE.
     */
    val requiredAudioPermission: String
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

    /**
     * Checks whether the necessary audio read permission is currently granted.
     */
    fun hasAudioPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            requiredAudioPermission
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Checks if a rationale dialog or explanation should be shown to the user.
     */
    fun shouldShowPermissionRationale(activity: Activity?): Boolean {
        return activity?.let {
            ActivityCompat.shouldShowRequestPermissionRationale(it, requiredAudioPermission)
        } ?: false
    }

    /**
     * Launches the system App Settings screen so the user can manually enable audio permission
     * if it was permanently denied.
     */
    fun openAppSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * Scans the Android MediaStore audio table asynchronously on the IO dispatcher.
     * Safely reads audio files, filters short ringtones/notifications, and builds
     * high-fidelity Song models.
     *
     * @param context Application or Activity context.
     * @param minDurationMs Minimum duration in milliseconds (default 10,000 ms to skip UI sounds).
     */
    suspend fun scanStorageForAudio(
        context: Context,
        minDurationMs: Long = 10_000L
    ): List<Song> = withContext(Dispatchers.IO) {
        val songs = mutableListOf<Song>()

        val collectionUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.SIZE
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ?"
        val selectionArgs = arrayOf(minDurationMs.toString())
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        try {
            context.contentResolver.query(
                collectionUri,
                projection,
                selection,
                selectionArgs,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val yearCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val rawTitle = cursor.getString(titleCol) ?: "Unknown Track"
                    val rawArtist = cursor.getString(artistCol) ?: "Local Artist"
                    val rawAlbum = cursor.getString(albumCol) ?: "Device Audio"
                    val albumId = cursor.getLong(albumIdCol)
                    val duration = cursor.getLong(durationCol)
                    val filePath = cursor.getString(dataCol)
                    val year = cursor.getInt(yearCol).let { if (it > 0) it else 2024 }

                    val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

                    // Resolve album artwork Uri if available
                    val albumArtUri = ContentUris.withAppendedId(
                        Uri.parse("content://media/external/audio/albumart"),
                        albumId
                    ).toString()

                    val cleanArtist = if (rawArtist.contains("<unknown>", ignoreCase = true) || rawArtist.isBlank()) {
                        "Local Artist"
                    } else rawArtist

                    val cleanAlbum = if (rawAlbum.contains("<unknown>", ignoreCase = true) || rawAlbum.isBlank()) {
                        "Device Storage"
                    } else rawAlbum

                    songs.add(
                        Song(
                            id = "local_$id",
                            title = rawTitle.trim(),
                            artist = cleanArtist.trim(),
                            album = cleanAlbum.trim(),
                            durationMs = duration,
                            audioUrl = contentUri.toString(),
                            artworkUrl = albumArtUri,
                            isLocal = true,
                            isDownloaded = true,
                            localFilePath = filePath,
                            genre = "Local Audio",
                            year = year
                        )
                    )
                }
            }
        } catch (e: SecurityException) {
            throw e
        } catch (e: Exception) {
            // Other storage or provider exception
        }

        songs
    }
}

/**
 * Controller holder returned by [rememberAudioScanLauncher].
 */
@Stable
class AudioScanLauncherController(
    private val context: Context,
    private val coroutineScope: CoroutineScope,
    private val launcher: ManagedActivityResultLauncher<String, Boolean>,
    private val onSongsFound: (List<Song>) -> Unit
) {
    var state by mutableStateOf<AudioScanState>(AudioScanState.Idle)
        private set

    val isScanning: Boolean
        get() = state is AudioScanState.Scanning

    val requiredPermission: String
        get() = LocalAudioScannerHelper.requiredAudioPermission

    /**
     * Initiates the local storage audio scan. If the appropriate permission
     * (READ_MEDIA_AUDIO on Android 13+, READ_EXTERNAL_STORAGE on Android 10-12) is already granted,
     * it proceeds immediately with the scan. Otherwise, it triggers the system permission dialog.
     */
    fun startScan() {
        if (LocalAudioScannerHelper.hasAudioPermission(context)) {
            executeScan()
        } else {
            state = AudioScanState.RequestingPermission
            launcher.launch(requiredPermission)
        }
    }

    /**
     * Callback invoked by the permission launcher result.
     */
    fun onPermissionResult(isGranted: Boolean) {
        if (isGranted) {
            executeScan()
        } else {
            val activity = context as? Activity
            val canShowRationale = LocalAudioScannerHelper.shouldShowPermissionRationale(activity)
            state = AudioScanState.PermissionDenied(
                isPermanent = !canShowRationale,
                rationale = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    "READ_MEDIA_AUDIO permission is required to read music stored on this device."
                } else {
                    "Storage permission is required to import audio files from device storage."
                }
            )
        }
    }

    private fun executeScan() {
        state = AudioScanState.Scanning()
        coroutineScope.launch {
            try {
                val songs = LocalAudioScannerHelper.scanStorageForAudio(context)
                state = AudioScanState.Success(songs, songs.size)
                onSongsFound(songs)
            } catch (e: SecurityException) {
                state = AudioScanState.PermissionDenied(
                    isPermanent = false,
                    rationale = "Permission revoked or denied by system."
                )
            } catch (e: Exception) {
                state = AudioScanState.Error(e.message ?: "Failed to scan device audio files.")
            }
        }
    }

    fun resetState() {
        state = AudioScanState.Idle
    }

    fun openSettings() {
        LocalAudioScannerHelper.openAppSettings(context)
    }
}

/**
 * Jetpack Compose helper to request READ_MEDIA_AUDIO (or READ_EXTERNAL_STORAGE on pre-13)
 * and scan local storage for audio files.
 *
 * @param onSongsFound Callback invoked with the scanned list of [Song]s upon completion.
 */
@Composable
fun rememberAudioScanLauncher(
    onSongsFound: (List<Song>) -> Unit
): AudioScanLauncherController {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var controller: AudioScanLauncherController? by remember { mutableStateOf(null) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        controller?.onPermissionResult(isGranted)
    }

    val instance = remember(context, coroutineScope, launcher) {
        AudioScanLauncherController(
            context = context,
            coroutineScope = coroutineScope,
            launcher = launcher,
            onSongsFound = onSongsFound
        ).also { controller = it }
    }

    return instance
}
