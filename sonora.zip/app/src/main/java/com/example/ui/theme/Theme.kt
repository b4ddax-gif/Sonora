package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = SonoraPrimary,
    onPrimary = Color.White,
    primaryContainer = SonoraDarkSurfaceElevated,
    onPrimaryContainer = SonoraPrimary,
    secondary = SonoraSecondary,
    onSecondary = Color.Black,
    tertiary = SonoraTertiary,
    background = SonoraDarkBackground,
    onBackground = SonoraTextPrimary,
    surface = SonoraDarkSurface,
    onSurface = SonoraTextPrimary,
    surfaceVariant = SonoraDarkSurfaceVariant,
    onSurfaceVariant = SonoraTextSecondary,
    outline = SonoraDivider,
    outlineVariant = SonoraCardBorder
)

private val LightColorScheme = lightColorScheme(
    primary = SonoraPrimaryVariant,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF3E8FF),
    onPrimaryContainer = SonoraPrimaryVariant,
    secondary = SonoraSecondary,
    onSecondary = Color.White,
    tertiary = SonoraTertiary,
    background = SonoraLightBackground,
    onBackground = SonoraLightTextPrimary,
    surface = SonoraLightSurface,
    onSurface = SonoraLightTextPrimary,
    surfaceVariant = SonoraLightSurfaceVariant,
    onSurfaceVariant = SonoraLightTextSecondary
)

@Composable
fun SonoraTheme(
    themePreference: String = "dark", // "dark", "light", "system"
    content: @Composable () -> Unit
) {
    val isDark = when (themePreference) {
        "light" -> false
        "dark" -> true
        else -> isSystemInDarkTheme()
    }

    val colorScheme = if (isDark) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Kept for backward compatibility
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    SonoraTheme(
        themePreference = if (darkTheme) "dark" else "light",
        content = content
    )
}
