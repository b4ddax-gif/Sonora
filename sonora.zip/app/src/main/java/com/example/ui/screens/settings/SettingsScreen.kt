package com.example.ui.screens.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AudioQuality
import com.example.ui.theme.SonoraDarkSurfaceElevated
import com.example.ui.theme.SonoraDarkSurfaceVariant
import com.example.ui.theme.SonoraPrimary
import com.example.ui.theme.SonoraSecondary
import com.example.ui.theme.SonoraTextMuted
import com.example.ui.theme.SonoraTextSecondary
import com.example.ui.util.FormatUtils

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var showThemeDialog by remember { mutableStateOf(false) }
    var showAudioQualityDialog by remember { mutableStateOf(false) }
    var showApiKeyDialog by remember { mutableStateOf(false) }
    var testUrlInput by remember { mutableStateOf("") }

    LaunchedEffect(uiState.infoMessage) {
        uiState.infoMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearInfoMessage()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Settings",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 90.dp, start = 20.dp, end = 20.dp)
            ) {
                // 1. APPEARANCE
                item {
                    SettingsSectionHeader("APPEARANCE")
                    SettingsItem(
                        icon = Icons.Default.DarkMode,
                        title = "Theme",
                        subtitle = when (uiState.themeMode) {
                            "light" -> "Light"
                            "dark" -> "Dark (AMOLED Obsidian)"
                            else -> "System Default"
                        },
                        onClick = { showThemeDialog = true }
                    )
                }

                // 2. AUDIO PLAYBACK & QUALITY
                item {
                    SettingsSectionHeader("AUDIO PLAYBACK & STREAMING")
                    SettingsItem(
                        icon = Icons.Default.HighQuality,
                        title = "Streaming Audio Quality",
                        subtitle = "${uiState.audioQuality.title} (${uiState.audioQuality.bitRate})",
                        onClick = { showAudioQualityDialog = true }
                    )
                    SettingsItem(
                        icon = Icons.Default.GraphicEq,
                        title = "Download Quality",
                        subtitle = "${uiState.downloadQuality} (High definition 320 kbps)",
                        onClick = {}
                    )
                }

                // 3. STORAGE & DATA
                item {
                    SettingsSectionHeader("STORAGE & DATA")
                    SettingsToggleItem(
                        icon = Icons.Default.Wifi,
                        title = "Download over Wi-Fi only",
                        subtitle = "Preserve cellular data allowance",
                        checked = uiState.wifiOnlyDownloads,
                        onCheckedChange = { viewModel.setWifiOnly(it) }
                    )
                    SettingsItem(
                        icon = Icons.Default.Storage,
                        title = "Downloaded Storage Used",
                        subtitle = FormatUtils.formatFileSize(uiState.storageUsageBytes),
                        trailing = {
                            TextButton(onClick = { viewModel.clearDownloads() }) {
                                Text("Clear", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    )
                    SettingsItem(
                        icon = Icons.Default.CleaningServices,
                        title = "Clear Search History",
                        subtitle = "Remove past search queries",
                        onClick = { viewModel.clearSearchHistory() }
                    )
                }

                // 4. GEMINI AI CONFIGURATION
                item {
                    SettingsSectionHeader("AI CURATOR")
                    SettingsItem(
                        icon = Icons.Default.AutoAwesome,
                        title = "Gemini API Configuration",
                        subtitle = if (uiState.apiKeyConfigured) "Key configured (Active neural curation)" else "Offline local music engine active",
                        onClick = { showApiKeyDialog = true }
                    )
                }

                // 5. LEGAL & COMPLIANCE GUARDRAIL TEST
                item {
                    SettingsSectionHeader("AUTHORIZED SOURCES & POLICY")
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = SonoraDarkSurfaceVariant),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = SonoraSecondary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Download Policy Guardrail",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Text(
                                text = "Sonora only allows downloads from authorized, user-owned, or licensed audio sources. Ripping from YouTube is strictly prohibited.",
                                style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )

                            OutlinedTextField(
                                value = testUrlInput,
                                onValueChange = {
                                    testUrlInput = it
                                    viewModel.clearYoutubeMessage()
                                },
                                label = { Text("Test Audio or Source URL") },
                                placeholder = { Text("https://...") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = { viewModel.testUrl(testUrlInput) },
                                enabled = testUrlInput.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = SonoraPrimary),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text("Verify Authorization")
                            }

                            uiState.youtubeTestMessage?.let { msg ->
                                val isError = msg.contains("Direct downloading from YouTube isn't supported")
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 10.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isError) MaterialTheme.colorScheme.errorContainer else SonoraDarkSurfaceElevated
                                ) {
                                    Text(
                                        text = msg,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = if (isError) MaterialTheme.colorScheme.onErrorContainer else SonoraPrimary
                                        ),
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // 6. ABOUT
                item {
                    SettingsSectionHeader("ABOUT SONORA")
                    SettingsItem(
                        icon = Icons.Default.Info,
                        title = "Sonora Music",
                        subtitle = "Version 1.0.0 • Modern Android 10-16 Media3 Player"
                    )
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }

    // Theme selector dialog
    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = { Text("Choose Theme") },
            text = {
                Column {
                    listOf("dark" to "Dark (Obsidian AMOLED)", "light" to "Light", "system" to "Follow System").forEach { (mode, title) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setTheme(mode)
                                    showThemeDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = uiState.themeMode == mode,
                                onClick = {
                                    viewModel.setTheme(mode)
                                    showThemeDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(title)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showThemeDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Audio Quality dialog
    if (showAudioQualityDialog) {
        AlertDialog(
            onDismissRequest = { showAudioQualityDialog = false },
            title = { Text("Audio Streaming Quality") },
            text = {
                Column {
                    AudioQuality.values().forEach { quality ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setAudioQuality(quality)
                                    showAudioQualityDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = uiState.audioQuality == quality,
                                onClick = {
                                    viewModel.setAudioQuality(quality)
                                    showAudioQualityDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(quality.title, fontWeight = FontWeight.SemiBold)
                                Text(quality.bitRate, style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary))
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAudioQualityDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // API Key dialog
    if (showApiKeyDialog) {
        var keyInput by remember { mutableStateOf(uiState.customApiKey) }
        AlertDialog(
            onDismissRequest = { showApiKeyDialog = false },
            title = { Text("Gemini API Key") },
            text = {
                Column {
                    Text(
                        text = "Enter a Gemini API key for live neural music recommendations. If left empty, Sonora uses its high-speed offline curation engine.",
                        style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    OutlinedTextField(
                        value = keyInput,
                        onValueChange = { keyInput = it },
                        label = { Text("API Key") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setCustomApiKey(keyInput)
                        showApiKeyDialog = false
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiKeyDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelSmall.copy(
            color = SonoraPrimary,
            letterSpacing = 1.2.sp,
            fontWeight = FontWeight.Bold
        ),
        modifier = Modifier.padding(top = 22.dp, bottom = 8.dp)
    )
}

@Composable
fun SettingsItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: (() -> Unit)? = null,
    trailing: @Composable (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = SonoraTextSecondary, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium))
            Text(subtitle, style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary))
        }
        trailing?.invoke()
    }
}

@Composable
fun SettingsToggleItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = SonoraTextSecondary, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium))
            Text(subtitle, style = MaterialTheme.typography.bodySmall.copy(color = SonoraTextSecondary))
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = SonoraPrimary)
        )
    }
}
