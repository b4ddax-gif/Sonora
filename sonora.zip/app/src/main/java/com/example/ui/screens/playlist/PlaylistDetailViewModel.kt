package com.example.ui.screens.playlist

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Playlist
import com.example.data.model.Song
import com.example.data.repository.DownloadRepository
import com.example.data.repository.MusicRepository
import com.example.playback.MusicPlayerManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PlaylistDetailUiState(
    val playlist: Playlist? = null,
    val songs: List<Song> = emptyList(),
    val isLoading: Boolean = true
)

class PlaylistDetailViewModel(
    private val playlistId: String,
    private val musicRepository: MusicRepository,
    private val downloadRepository: DownloadRepository,
    private val playerManager: MusicPlayerManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(PlaylistDetailUiState())
    val uiState: StateFlow<PlaylistDetailUiState> = _uiState.asStateFlow()

    init {
        loadPlaylist()
    }

    private fun loadPlaylist() {
        viewModelScope.launch {
            musicRepository.getPlaylistWithSongs(playlistId).collect { pair ->
                _uiState.value = PlaylistDetailUiState(
                    playlist = pair.first,
                    songs = pair.second,
                    isLoading = false
                )
            }
        }
    }

    fun playSong(song: Song) {
        playerManager.playSong(song, _uiState.value.songs)
    }

    fun playAll() {
        val list = _uiState.value.songs
        if (list.isNotEmpty()) {
            playerManager.playQueue(list, 0)
        }
    }

    fun shuffleAll() {
        val list = _uiState.value.songs
        if (list.isNotEmpty()) {
            playerManager.playSong(list.shuffled().first(), list)
        }
    }

    fun removeSongFromPlaylist(songId: String) {
        viewModelScope.launch {
            musicRepository.removeSongFromPlaylist(playlistId, songId)
        }
    }

    fun renamePlaylist(newTitle: String) {
        viewModelScope.launch {
            musicRepository.renamePlaylist(playlistId, newTitle)
        }
    }

    fun deletePlaylist(onDeleted: () -> Unit) {
        viewModelScope.launch {
            musicRepository.deletePlaylist(playlistId)
            onDeleted()
        }
    }

    fun toggleFavorite(songId: String) {
        viewModelScope.launch {
            musicRepository.toggleFavorite(songId)
        }
    }

    fun addToQueue(song: Song) {
        playerManager.addToQueue(song)
    }

    fun downloadSong(song: Song) {
        viewModelScope.launch {
            downloadRepository.startDownload(song)
        }
    }

    fun deleteDownload(songId: String) {
        viewModelScope.launch {
            downloadRepository.deleteDownload(songId)
        }
    }
}

class PlaylistDetailViewModelFactory(
    private val playlistId: String,
    private val musicRepository: MusicRepository,
    private val downloadRepository: DownloadRepository,
    private val playerManager: MusicPlayerManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return PlaylistDetailViewModel(playlistId, musicRepository, downloadRepository, playerManager) as T
    }
}
