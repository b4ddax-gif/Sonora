package com.example.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Artist
import com.example.data.model.Playlist
import com.example.data.model.Song
import com.example.data.repository.DownloadRepository
import com.example.data.repository.MusicRepository
import com.example.playback.MusicPlayerManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val recentlyPlayed: List<Song> = emptyList(),
    val trendingSongs: List<Song> = emptyList(),
    val recommendedPlaylists: List<Playlist> = emptyList(),
    val featuredArtists: List<Artist> = emptyList(),
    val continueListeningSong: Song? = null,
    val isLoading: Boolean = false
)

class HomeViewModel(
    private val musicRepository: MusicRepository,
    private val downloadRepository: DownloadRepository,
    private val playerManager: MusicPlayerManager
) : ViewModel() {

    val uiState: StateFlow<HomeUiState> = combine(
        musicRepository.getAllSongs(),
        musicRepository.getRecentlyPlayed(),
        musicRepository.getAllPlaylists(),
        musicRepository.getAllArtists()
    ) { allSongs, recentlyPlayed, playlists, artists ->
        HomeUiState(
            recentlyPlayed = recentlyPlayed.take(10),
            trendingSongs = allSongs.take(8),
            recommendedPlaylists = playlists,
            featuredArtists = artists,
            continueListeningSong = recentlyPlayed.firstOrNull() ?: allSongs.firstOrNull(),
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState(isLoading = true)
    )

    fun playSong(song: Song, queue: List<Song> = emptyList()) {
        playerManager.playSong(song, queue)
    }

    fun playQueue(songs: List<Song>, startIndex: Int = 0) {
        playerManager.playQueue(songs, startIndex)
    }

    fun toggleFavorite(songId: String) {
        viewModelScope.launch {
            musicRepository.toggleFavorite(songId)
        }
    }

    fun addToPlaylist(playlistId: String, songId: String) {
        viewModelScope.launch {
            musicRepository.addSongToPlaylist(playlistId, songId)
        }
    }

    fun createPlaylistAndAddSong(title: String, songId: String) {
        viewModelScope.launch {
            val playlistId = musicRepository.createPlaylist(title)
            musicRepository.addSongToPlaylist(playlistId, songId)
        }
    }

    fun downloadSong(song: Song) {
        viewModelScope.launch {
            downloadRepository.startDownload(song)
        }
    }

    fun deleteDownload(songId: String) {
        viewModelScope.launch {
            downloadRepository.deleteDownload(songId)
        }
    }

    fun addToQueue(song: Song) {
        playerManager.addToQueue(song)
    }
}

class HomeViewModelFactory(
    private val musicRepository: MusicRepository,
    private val downloadRepository: DownloadRepository,
    private val playerManager: MusicPlayerManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return HomeViewModel(musicRepository, downloadRepository, playerManager) as T
    }
}
