package com.example.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AudioQuality
import com.example.data.preferences.SonoraSettings
import com.example.data.repository.DownloadRepository
import com.example.data.repository.GeminiRecommendationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SettingsUiState(
    val themeMode: String = "dark",
    val audioQuality: AudioQuality = AudioQuality.HIGH,
    val downloadQuality: String = "High",
    val wifiOnlyDownloads: Boolean = false,
    val storageUsageBytes: Long = 0L,
    val apiKeyConfigured: Boolean = false,
    val customApiKey: String = "",
    val youtubeTestMessage: String? = null,
    val infoMessage: String? = null
)

class SettingsViewModel(
    private val settings: SonoraSettings,
    private val downloadRepository: DownloadRepository,
    private val geminiRepository: GeminiRecommendationRepository
) : ViewModel() {

    private val _youtubeMessage = MutableStateFlow<String?>(null)
    private val _infoMessage = MutableStateFlow<String?>(null)
    private val messagesFlow = combine(_youtubeMessage, _infoMessage) { yt, info -> Pair(yt, info) }

    val uiState: StateFlow<SettingsUiState> = combine(
        settings.themeMode,
        settings.audioQuality,
        settings.downloadQuality,
        settings.wifiOnlyDownloads,
        messagesFlow
    ) { theme, audioQ, dlQ, wifiOnly, (ytMsg, infoMsg) ->
        SettingsUiState(
            themeMode = theme,
            audioQuality = audioQ,
            downloadQuality = dlQ,
            wifiOnlyDownloads = wifiOnly,
            storageUsageBytes = downloadRepository.getStorageUsageBytes(),
            apiKeyConfigured = geminiRepository.hasApiKey(),
            customApiKey = geminiRepository.customApiKey ?: "",
            youtubeTestMessage = ytMsg,
            infoMessage = infoMsg
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SettingsUiState()
    )

    fun setTheme(theme: String) {
        settings.setThemeMode(theme)
    }

    fun setAudioQuality(quality: AudioQuality) {
        settings.setAudioQuality(quality)
    }

    fun setDownloadQuality(quality: String) {
        settings.setDownloadQuality(quality)
    }

    fun setWifiOnly(enabled: Boolean) {
        settings.setWifiOnlyDownloads(enabled)
    }

    fun clearDownloads() {
        viewModelScope.launch {
            downloadRepository.clearAllDownloads()
            _infoMessage.value = "All downloaded tracks cleared."
        }
    }

    fun clearSearchHistory() {
        settings.clearSearchHistory()
        _infoMessage.value = "Search history cleared."
    }

    fun setCustomApiKey(key: String) {
        geminiRepository.customApiKey = key.trim()
        _infoMessage.value = if (key.isNotBlank()) "Gemini API key updated." else "Gemini API key removed."
    }

    fun testUrl(inputUrl: String) {
        if (DownloadRepository.isYouTubeUrl(inputUrl)) {
            _youtubeMessage.value = DownloadRepository.YOUTUBE_ERROR_MESSAGE
        } else {
            _youtubeMessage.value = "Valid audio link. Authorized for Sonora playback."
        }
    }

    fun clearYoutubeMessage() {
        _youtubeMessage.value = null
    }

    fun clearInfoMessage() {
        _infoMessage.value = null
    }
}

class SettingsViewModelFactory(
    private val settings: SonoraSettings,
    private val downloadRepository: DownloadRepository,
    private val geminiRepository: GeminiRecommendationRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return SettingsViewModel(settings, downloadRepository, geminiRepository) as T
    }
}
