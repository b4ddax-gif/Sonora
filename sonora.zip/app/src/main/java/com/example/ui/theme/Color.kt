package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sonora Brand Colors
val SonoraDarkBackground = Color(0xFF090A0F)
val SonoraDarkSurface = Color(0xFF11131B)
val SonoraDarkSurfaceVariant = Color(0xFF181B26)
val SonoraDarkSurfaceElevated = Color(0xFF222636)

val SonoraPrimary = Color(0xFFA855F7) // Electric Purple
val SonoraPrimaryVariant = Color(0xFF9333EA)
val SonoraSecondary = Color(0xFF06B6D4) // Neon Cyan
val SonoraTertiary = Color(0xFFF43F5E) // Sunset Rose

val SonoraTextPrimary = Color(0xFFF8FAFC)
val SonoraTextSecondary = Color(0xFF94A3B8)
val SonoraTextMuted = Color(0xFF64748B)

val SonoraCardBorder = Color(0x1FFFFFFF)
val SonoraDivider = Color(0x14FFFFFF)

// Light Theme Fallbacks
val SonoraLightBackground = Color(0xFFF8FAFC)
val SonoraLightSurface = Color(0xFFFFFFFF)
val SonoraLightSurfaceVariant = Color(0xFFF1F5F9)
val SonoraLightTextPrimary = Color(0xFF0F172A)
val SonoraLightTextSecondary = Color(0xFF475569)
