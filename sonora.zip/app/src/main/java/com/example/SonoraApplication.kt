package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.preferences.SonoraSettings
import com.example.data.repository.DownloadRepository
import com.example.data.repository.GeminiRecommendationRepository
import com.example.data.repository.LocalMusicScanner
import com.example.data.repository.MusicRepository
import com.example.data.repository.MusicRepositoryImpl
import com.example.playback.MusicPlayerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SonoraApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var musicRepository: MusicRepository
        private set

    lateinit var downloadRepository: DownloadRepository
        private set

    lateinit var geminiRepository: GeminiRecommendationRepository
        private set

    lateinit var localMusicScanner: LocalMusicScanner
        private set

    lateinit var settings: SonoraSettings
        private set

    lateinit var playerManager: MusicPlayerManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.getInstance(this)
        musicRepository = MusicRepositoryImpl(database)
        downloadRepository = DownloadRepository(this, database)
        geminiRepository = GeminiRecommendationRepository()
        localMusicScanner = LocalMusicScanner(this)
        settings = SonoraSettings(this)
        playerManager = MusicPlayerManager(this, musicRepository)

        // Seed initial mock / licensed sample tracks so UI looks vibrant on first launch
        CoroutineScope(Dispatchers.IO).launch {
            musicRepository.initializeSampleDataIfNeeded()
        }
    }

    companion object {
        lateinit var instance: SonoraApplication
            private set
    }
}
