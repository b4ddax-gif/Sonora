package com.example.playback

import android.content.Context
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.data.model.RepeatMode
import com.example.data.model.Song
import com.example.data.repository.MusicRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class MusicPlayerManager(
    private val context: Context,
    private val musicRepository: MusicRepository
) {
    private val scope = CoroutineScope(Dispatchers.Main)

    private val player: ExoPlayer by lazy {
        ExoPlayer.Builder(context.applicationContext)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build().apply {
                addListener(playerListener)
            }
    }

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _queue = MutableStateFlow<List<Song>>(emptyList())
    val queue: StateFlow<List<Song>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _isShuffleEnabled = MutableStateFlow(false)
    val isShuffleEnabled: StateFlow<Boolean> = _isShuffleEnabled.asStateFlow()

    private val _repeatMode = MutableStateFlow(RepeatMode.OFF)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _playbackError = MutableStateFlow<String?>(null)
    val playbackError: StateFlow<String?> = _playbackError.asStateFlow()

    private var progressJob: Job? = null
    private var originalQueue: List<Song> = emptyList()

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
            if (isPlaying) {
                startProgressTracker()
            } else {
                stopProgressTracker()
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            when (playbackState) {
                Player.STATE_BUFFERING -> {
                    _isLoading.value = true
                    _playbackError.value = null
                }
                Player.STATE_READY -> {
                    _isLoading.value = false
                    _playbackError.value = null
                    val dur = player.duration
                    if (dur > 0) {
                        _durationMs.value = dur
                    }
                }
                Player.STATE_ENDED -> {
                    _isLoading.value = false
                    handlePlaybackEnded()
                }
                Player.STATE_IDLE -> {
                    _isLoading.value = false
                }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            _isLoading.value = false
            _isPlaying.value = false
            stopProgressTracker()

            val errorMessage = when (error.errorCode) {
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                    "Network error while streaming audio. Check your internet connection."
                PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
                    "Audio file could not be found."
                PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
                PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ->
                    "Unsupported audio format or corrupt file."
                else -> "Playback error: ${error.message ?: "Unable to play track"}"
            }
            _playbackError.value = errorMessage
        }
    }

    fun playSong(song: Song, newQueue: List<Song> = emptyList()) {
        val queueToUse = if (newQueue.isNotEmpty()) newQueue else listOf(song)
        originalQueue = queueToUse
        val list = if (_isShuffleEnabled.value) {
            listOf(song) + (queueToUse - song).shuffled()
        } else {
            queueToUse
        }
        _queue.value = list
        val index = list.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        _currentIndex.value = index

        loadAndPlay(song)
    }

    fun playQueue(songs: List<Song>, startIndex: Int = 0) {
        if (songs.isEmpty()) return
        originalQueue = songs
        val list = if (_isShuffleEnabled.value) {
            val startSong = songs.getOrElse(startIndex) { songs.first() }
            listOf(startSong) + (songs - startSong).shuffled()
        } else {
            songs
        }
        _queue.value = list
        val index = if (_isShuffleEnabled.value) 0 else startIndex.coerceIn(0, songs.lastIndex)
        _currentIndex.value = index

        loadAndPlay(list[index])
    }

    private fun loadAndPlay(song: Song) {
        _currentSong.value = song
        _durationMs.value = song.durationMs
        _currentPositionMs.value = 0L
        _playbackError.value = null
        _isLoading.value = true

        scope.launch {
            musicRepository.recordRecentlyPlayed(song.id)
        }

        try {
            val audioUri = if (song.isDownloaded && !song.localFilePath.isNullOrBlank()) {
                val file = File(song.localFilePath)
                if (file.exists() && file.length() > 0) {
                    Uri.fromFile(file)
                } else {
                    Uri.parse(song.audioUrl)
                }
            } else if (song.isLocal && !song.localFilePath.isNullOrBlank()) {
                Uri.fromFile(File(song.localFilePath))
            } else {
                Uri.parse(song.audioUrl)
            }

            val mediaMetadata = MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setAlbumTitle(song.album)
                .setArtworkUri(Uri.parse(song.artworkUrl))
                .build()

            val mediaItem = MediaItem.Builder()
                .setMediaId(song.id)
                .setUri(audioUri)
                .setMediaMetadata(mediaMetadata)
                .build()

            player.setMediaItem(mediaItem)
            player.prepare()
            player.play()
            _isPlaying.value = true
        } catch (e: Exception) {
            _isLoading.value = false
            _playbackError.value = "Failed to load audio: ${e.message}"
        }
    }

    fun togglePlayPause() {
        if (_currentSong.value == null) {
            val first = _queue.value.firstOrNull()
            if (first != null) {
                loadAndPlay(first)
            }
            return
        }

        if (player.isPlaying) {
            player.pause()
            _isPlaying.value = false
        } else {
            player.play()
            _isPlaying.value = true
        }
    }

    fun seekTo(positionMs: Long) {
        val target = positionMs.coerceIn(0L, _durationMs.value.coerceAtLeast(1000L))
        _currentPositionMs.value = target
        player.seekTo(target)
    }

    fun skipToNext() {
        val q = _queue.value
        if (q.isEmpty()) return

        val nextIndex = _currentIndex.value + 1
        if (nextIndex < q.size) {
            _currentIndex.value = nextIndex
            loadAndPlay(q[nextIndex])
        } else if (_repeatMode.value == RepeatMode.ALL) {
            _currentIndex.value = 0
            loadAndPlay(q[0])
        } else {
            player.pause()
            _isPlaying.value = false
            player.seekTo(0)
            _currentPositionMs.value = 0L
        }
    }

    fun skipToPrevious() {
        // If passed 3 seconds, seek back to beginning of current song
        if (player.currentPosition > 3000) {
            seekTo(0)
            return
        }

        val q = _queue.value
        if (q.isEmpty()) return

        val prevIndex = _currentIndex.value - 1
        if (prevIndex >= 0) {
            _currentIndex.value = prevIndex
            loadAndPlay(q[prevIndex])
        } else if (_repeatMode.value == RepeatMode.ALL) {
            _currentIndex.value = q.lastIndex
            loadAndPlay(q[q.lastIndex])
        } else {
            seekTo(0)
        }
    }

    fun toggleShuffle() {
        val newShuffle = !_isShuffleEnabled.value
        _isShuffleEnabled.value = newShuffle

        val current = _currentSong.value
        if (current != null && originalQueue.isNotEmpty()) {
            if (newShuffle) {
                val shuffled = listOf(current) + (originalQueue - current).shuffled()
                _queue.value = shuffled
                _currentIndex.value = 0
            } else {
                _queue.value = originalQueue
                _currentIndex.value = originalQueue.indexOfFirst { it.id == current.id }.coerceAtLeast(0)
            }
        }
    }

    fun toggleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
    }

    fun playFromQueue(index: Int) {
        val q = _queue.value
        if (index in q.indices) {
            _currentIndex.value = index
            loadAndPlay(q[index])
        }
    }

    fun addToQueue(song: Song) {
        val updated = _queue.value + song
        _queue.value = updated
        originalQueue = originalQueue + song
    }

    fun removeFromQueue(index: Int) {
        val q = _queue.value.toMutableList()
        if (index in q.indices) {
            val removed = q.removeAt(index)
            _queue.value = q
            if (index == _currentIndex.value) {
                if (q.isNotEmpty()) {
                    val next = index.coerceAtMost(q.lastIndex)
                    _currentIndex.value = next
                    loadAndPlay(q[next])
                } else {
                    player.stop()
                    _currentSong.value = null
                    _isPlaying.value = false
                }
            } else if (index < _currentIndex.value) {
                _currentIndex.value = _currentIndex.value - 1
            }
        }
    }

    fun clearQueue() {
        player.stop()
        _queue.value = emptyList()
        originalQueue = emptyList()
        _currentSong.value = null
        _isPlaying.value = false
        _currentPositionMs.value = 0L
    }

    fun retryPlayback() {
        val song = _currentSong.value
        if (song != null) {
            loadAndPlay(song)
        }
    }

    private fun handlePlaybackEnded() {
        when (_repeatMode.value) {
            RepeatMode.ONE -> {
                seekTo(0)
                player.play()
                _isPlaying.value = true
            }
            RepeatMode.ALL -> {
                skipToNext()
            }
            RepeatMode.OFF -> {
                val nextIndex = _currentIndex.value + 1
                if (nextIndex < _queue.value.size) {
                    _currentIndex.value = nextIndex
                    loadAndPlay(_queue.value[nextIndex])
                } else {
                    _isPlaying.value = false
                    seekTo(0)
                }
            }
        }
    }

    private fun startProgressTracker() {
        stopProgressTracker()
        progressJob = scope.launch {
            while (isActive) {
                if (player.isPlaying) {
                    _currentPositionMs.value = player.currentPosition
                    val d = player.duration
                    if (d > 0) {
                        _durationMs.value = d
                    }
                }
                delay(250)
            }
        }
    }

    private fun stopProgressTracker() {
        progressJob?.cancel()
        progressJob = null
    }

    fun release() {
        stopProgressTracker()
        player.removeListener(playerListener)
        player.release()
    }
}
