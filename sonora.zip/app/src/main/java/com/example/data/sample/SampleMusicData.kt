package com.example.data.sample

import com.example.data.local.entity.AlbumEntity
import com.example.data.local.entity.ArtistEntity
import com.example.data.local.entity.PlaylistEntity
import com.example.data.local.entity.PlaylistSongEntity
import com.example.data.local.entity.SongEntity
import com.example.data.model.Song

object SampleMusicData {

    // Royalty-free / public domain streaming audio tracks for authorized playback
    private const val AUDIO_URL_1 = "https://ia801503.us.archive.org/15/items/audio_sample_track_01/ambient_wave.mp3"
    private const val AUDIO_URL_2 = "https://ia800301.us.archive.org/12/items/sample-music-audio-track/synth_journey.mp3"
    private const val AUDIO_URL_3 = "https://ia801402.us.archive.org/20/items/free_music_public_domain_03/chill_drift.mp3"
    private const val AUDIO_URL_4 = "https://ia801600.us.archive.org/11/items/sample_audio_free_lic_04/indie_sun.mp3"
    private const val AUDIO_URL_5 = "https://ia800508.us.archive.org/18/items/sound_track_open_05/night_pulse.mp3"
    private const val AUDIO_URL_6 = "https://ia800204.us.archive.org/23/items/sample_sound_free_06/lofi_study.mp3"

    val baseSongs = listOf(
        SongEntity(
            id = "track_1",
            title = "Midnight Neon",
            artist = "Aura Synthetica",
            album = "Neon Horizons",
            durationMs = 214000,
            audioUrl = AUDIO_URL_1,
            artworkUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80",
            genre = "Synthwave",
            year = 2024
        ),
        SongEntity(
            id = "track_2",
            title = "Cyber Dreams",
            artist = "Nova Pulse",
            album = "Neon Horizons",
            durationMs = 188000,
            audioUrl = AUDIO_URL_2,
            artworkUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&auto=format&fit=crop&q=80",
            genre = "Electronic",
            year = 2024
        ),
        SongEntity(
            id = "track_3",
            title = "Echoes of Silence",
            artist = "Celeste River",
            album = "Solitude & Solace",
            durationMs = 245000,
            audioUrl = AUDIO_URL_3,
            artworkUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
            genre = "Ambient",
            year = 2023
        ),
        SongEntity(
            id = "track_4",
            title = "Golden Hour Glow",
            artist = "The Solar Collective",
            album = "Sunlight Memoirs",
            durationMs = 196000,
            audioUrl = AUDIO_URL_4,
            artworkUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80",
            genre = "Indie",
            year = 2024
        ),
        SongEntity(
            id = "track_5",
            title = "Velvet Dusk",
            artist = "Luna Vibe",
            album = "Midnight Coffee",
            durationMs = 172000,
            audioUrl = AUDIO_URL_5,
            artworkUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80",
            genre = "Lo-Fi",
            year = 2024
        ),
        SongEntity(
            id = "track_6",
            title = "Hyperdrive 1984",
            artist = "Aura Synthetica",
            album = "Neon Horizons",
            durationMs = 228000,
            audioUrl = AUDIO_URL_6,
            artworkUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
            genre = "Synthwave",
            year = 2024
        ),
        SongEntity(
            id = "track_7",
            title = "Starlight Drift",
            artist = "Celeste River",
            album = "Solitude & Solace",
            durationMs = 260000,
            audioUrl = AUDIO_URL_1,
            artworkUrl = "https://images.unsplash.com/photo-1506157786151-b8491531f063?w=600&auto=format&fit=crop&q=80",
            genre = "Ambient",
            year = 2023
        ),
        SongEntity(
            id = "track_8",
            title = "Coffee & Raindrops",
            artist = "Luna Vibe",
            album = "Midnight Coffee",
            durationMs = 185000,
            audioUrl = AUDIO_URL_2,
            artworkUrl = "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=600&auto=format&fit=crop&q=80",
            genre = "Lo-Fi",
            year = 2024
        ),
        SongEntity(
            id = "track_9",
            title = "Mountain Breeze",
            artist = "The Solar Collective",
            album = "Sunlight Memoirs",
            durationMs = 210000,
            audioUrl = AUDIO_URL_4,
            artworkUrl = "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=600&auto=format&fit=crop&q=80",
            genre = "Indie",
            year = 2024
        ),
        SongEntity(
            id = "track_10",
            title = "Aurora Borealis",
            artist = "Symphony of Cosmos",
            album = "Universal Echoes",
            durationMs = 310000,
            audioUrl = AUDIO_URL_3,
            artworkUrl = "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=600&auto=format&fit=crop&q=80",
            genre = "Cinematic",
            year = 2024
        )
    )

    // Indian Songs Catalog
    val indianSongs = listOf(
        SongEntity(
            id = "track_in_1",
            title = "Kesariya Sufi Soul",
            artist = "Arijit & The Bombay Strings",
            album = "Bollywood & Sufi Nights",
            durationMs = 268000,
            audioUrl = AUDIO_URL_1,
            artworkUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
            genre = "Bollywood & Sufi",
            year = 2024
        ),
        SongEntity(
            id = "track_in_2",
            title = "Raga Bhairavi (Dawn Awakening)",
            artist = "Pandit Ravi & Anoushka",
            album = "Sacred Sitar Melodies",
            durationMs = 315000,
            audioUrl = AUDIO_URL_3,
            artworkUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80",
            genre = "Indian Classical",
            year = 2023
        ),
        SongEntity(
            id = "track_in_3",
            title = "Tum Hi Ho (Acoustic Reprise)",
            artist = "Arijit & The Bombay Strings",
            album = "Bollywood & Sufi Nights",
            durationMs = 254000,
            audioUrl = AUDIO_URL_5,
            artworkUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80",
            genre = "Bollywood & Sufi",
            year = 2024
        ),
        SongEntity(
            id = "track_in_4",
            title = "Morning Bansuri Meditation",
            artist = "Bansuri Breeze",
            album = "Vedic Flute Echoes",
            durationMs = 280000,
            audioUrl = AUDIO_URL_2,
            artworkUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
            genre = "Indian Classical",
            year = 2024
        ),
        SongEntity(
            id = "track_in_5",
            title = "Desert Mirage (Thar Folk)",
            artist = "Rajasthani Folk Collective",
            album = "Echoes of Rajasthan",
            durationMs = 224000,
            audioUrl = AUDIO_URL_4,
            artworkUrl = "https://images.unsplash.com/photo-1506157786151-b8491531f063?w=600&auto=format&fit=crop&q=80",
            genre = "Indian Folk",
            year = 2023
        ),
        SongEntity(
            id = "track_in_6",
            title = "Mumbai Monsoon Rain",
            artist = "Bombay Indie Project",
            album = "Monsoon Chords",
            durationMs = 212000,
            audioUrl = AUDIO_URL_6,
            artworkUrl = "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=600&auto=format&fit=crop&q=80",
            genre = "Indian Indie",
            year = 2024
        ),
        SongEntity(
            id = "track_in_7",
            title = "Tabla Beats & Sitar Groove",
            artist = "Zakir & The Rhythm Caravan",
            album = "Rhythms of India",
            durationMs = 204000,
            audioUrl = AUDIO_URL_1,
            artworkUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&auto=format&fit=crop&q=80",
            genre = "Fusion Beats",
            year = 2024
        ),
        SongEntity(
            id = "track_in_8",
            title = "Chai & Morning Ragas",
            artist = "Flute & Santoor Symphony",
            album = "Vedic Flute Echoes",
            durationMs = 245000,
            audioUrl = AUDIO_URL_3,
            artworkUrl = "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=600&auto=format&fit=crop&q=80",
            genre = "Indian Classical",
            year = 2024
        )
    )

    val songs = baseSongs + indianSongs

    // Indian Albums
    val indianAlbums = listOf(
        AlbumEntity(
            id = "album_in_1",
            title = "Bollywood & Sufi Nights",
            artist = "Arijit & The Bombay Strings",
            artworkUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
            songCount = 2,
            year = 2024
        ),
        AlbumEntity(
            id = "album_in_2",
            title = "Sacred Sitar Melodies",
            artist = "Pandit Ravi & Anoushka",
            artworkUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80",
            songCount = 1,
            year = 2023
        ),
        AlbumEntity(
            id = "album_in_3",
            title = "Vedic Flute Echoes",
            artist = "Bansuri Breeze",
            artworkUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
            songCount = 2,
            year = 2024
        ),
        AlbumEntity(
            id = "album_in_4",
            title = "Echoes of Rajasthan",
            artist = "Rajasthani Folk Collective",
            artworkUrl = "https://images.unsplash.com/photo-1506157786151-b8491531f063?w=600&auto=format&fit=crop&q=80",
            songCount = 1,
            year = 2023
        ),
        AlbumEntity(
            id = "album_in_5",
            title = "Rhythms of India",
            artist = "Zakir & The Rhythm Caravan",
            artworkUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&auto=format&fit=crop&q=80",
            songCount = 1,
            year = 2024
        )
    )

    val baseAlbums = listOf(
        AlbumEntity(
            id = "album_1",
            title = "Neon Horizons",
            artist = "Aura Synthetica",
            artworkUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80",
            songCount = 3,
            year = 2024
        ),
        AlbumEntity(
            id = "album_2",
            title = "Solitude & Solace",
            artist = "Celeste River",
            artworkUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
            songCount = 2,
            year = 2023
        ),
        AlbumEntity(
            id = "album_3",
            title = "Sunlight Memoirs",
            artist = "The Solar Collective",
            artworkUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80",
            songCount = 2,
            year = 2024
        ),
        AlbumEntity(
            id = "album_4",
            title = "Midnight Coffee",
            artist = "Luna Vibe",
            artworkUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80",
            songCount = 2,
            year = 2024
        ),
        AlbumEntity(
            id = "album_5",
            title = "Universal Echoes",
            artist = "Symphony of Cosmos",
            artworkUrl = "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=600&auto=format&fit=crop&q=80",
            songCount = 1,
            year = 2024
        )
    )

    val albums = baseAlbums + indianAlbums

    // Indian Artists
    val indianArtists = listOf(
        ArtistEntity(
            id = "artist_in_1",
            name = "Arijit & The Bombay Strings",
            artworkUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
            genre = "Bollywood & Sufi",
            bio = "Heart-stirring Bollywood vocals intertwined with acoustic guitars and lush string orchestras."
        ),
        ArtistEntity(
            id = "artist_in_2",
            name = "Pandit Ravi & Anoushka",
            artworkUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80",
            genre = "Indian Classical",
            bio = "Virtuosic sitar compositions evoking the ancient ragas and dawn ragas of India."
        ),
        ArtistEntity(
            id = "artist_in_3",
            name = "Bansuri Breeze",
            artworkUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
            genre = "Indian Classical",
            bio = "Meditative bamboo flute music composed for mindfulness, yoga, and inner tranquility."
        ),
        ArtistEntity(
            id = "artist_in_4",
            name = "Zakir & The Rhythm Caravan",
            artworkUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&auto=format&fit=crop&q=80",
            genre = "Fusion Beats",
            bio = "Electrifying tabla rhythms fused with contemporary electronic world music."
        ),
        ArtistEntity(
            id = "artist_in_5",
            name = "Rajasthani Folk Collective",
            artworkUrl = "https://images.unsplash.com/photo-1506157786151-b8491531f063?w=600&auto=format&fit=crop&q=80",
            genre = "Indian Folk",
            bio = "Soulful desert folk with sarangi, dholak, and raw desert balladeers."
        )
    )

    val baseArtists = listOf(
        ArtistEntity(
            id = "artist_1",
            name = "Aura Synthetica",
            artworkUrl = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&auto=format&fit=crop&q=80",
            genre = "Synthwave",
            bio = "Pioneering retro-futuristic soundscapes and pulsing analog synthesizers from Berlin."
        ),
        ArtistEntity(
            id = "artist_2",
            name = "Celeste River",
            artworkUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
            genre = "Ambient",
            bio = "Minimalist acoustic and modular ambient composer crafting atmospheric calm."
        ),
        ArtistEntity(
            id = "artist_3",
            name = "The Solar Collective",
            artworkUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80",
            genre = "Indie",
            bio = "Sunny guitars, warm harmonies, and organic percussion inspired by coastal summers."
        ),
        ArtistEntity(
            id = "artist_4",
            name = "Luna Vibe",
            artworkUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80",
            genre = "Lo-Fi",
            bio = "Lo-Fi hip hop and chill jazzy chords engineered for late-night study and coding."
        ),
        ArtistEntity(
            id = "artist_5",
            name = "Symphony of Cosmos",
            artworkUrl = "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=600&auto=format&fit=crop&q=80",
            genre = "Cinematic",
            bio = "Epic hybrid orchestral and celestial strings celebrating astronomical discovery."
        )
    )

    val artists = baseArtists + indianArtists

    // "All Indian Songs" Playlist
    val indianPlaylist = PlaylistEntity(
        id = "playlist_indian",
        title = "All Indian Songs",
        description = "The ultimate collection of Indian classical sitar & flute ragas, Bollywood acoustics, Sufi melodies, and vibrant indie folk.",
        artworkUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
        createdAt = System.currentTimeMillis() - 86400000 * 2
    )

    val indianPlaylistSongs = listOf(
        PlaylistSongEntity("playlist_indian", "track_in_1", 0),
        PlaylistSongEntity("playlist_indian", "track_in_2", 1),
        PlaylistSongEntity("playlist_indian", "track_in_3", 2),
        PlaylistSongEntity("playlist_indian", "track_in_4", 3),
        PlaylistSongEntity("playlist_indian", "track_in_5", 4),
        PlaylistSongEntity("playlist_indian", "track_in_6", 5),
        PlaylistSongEntity("playlist_indian", "track_in_7", 6),
        PlaylistSongEntity("playlist_indian", "track_in_8", 7)
    )

    val basePlaylists = listOf(
        PlaylistEntity(
            id = "playlist_1",
            title = "Deep Focus & Flow",
            description = "Gentle beats and ambient soundscapes to elevate concentration.",
            artworkUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
            createdAt = System.currentTimeMillis() - 86400000 * 5
        ),
        PlaylistEntity(
            id = "playlist_2",
            title = "Neon Night Drive",
            description = "High octane synthwave and pulsating retro rhythms for after-hours drives.",
            artworkUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80",
            createdAt = System.currentTimeMillis() - 86400000 * 3
        ),
        PlaylistEntity(
            id = "playlist_3",
            title = "Acoustic Warmth",
            description = "Soothing acoustic guitars and soulful melodies for relaxing afternoons.",
            artworkUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80",
            createdAt = System.currentTimeMillis() - 86400000 * 1
        )
    )

    val playlists = listOf(indianPlaylist) + basePlaylists

    val basePlaylistSongs = listOf(
        PlaylistSongEntity("playlist_1", "track_3", 0),
        PlaylistSongEntity("playlist_1", "track_5", 1),
        PlaylistSongEntity("playlist_1", "track_7", 2),
        PlaylistSongEntity("playlist_1", "track_8", 3),

        PlaylistSongEntity("playlist_2", "track_1", 0),
        PlaylistSongEntity("playlist_2", "track_2", 1),
        PlaylistSongEntity("playlist_2", "track_6", 2),

        PlaylistSongEntity("playlist_3", "track_4", 0),
        PlaylistSongEntity("playlist_3", "track_9", 1),
        PlaylistSongEntity("playlist_3", "track_3", 2)
    )

    val playlistSongs = indianPlaylistSongs + basePlaylistSongs

    val SAMPLE_SONGS: List<Song> = songs.map { entity ->
        Song(
            id = entity.id,
            title = entity.title,
            artist = entity.artist,
            album = entity.album,
            durationMs = entity.durationMs,
            audioUrl = entity.audioUrl,
            artworkUrl = entity.artworkUrl,
            genre = entity.genre,
            year = entity.year
        )
    }
}
