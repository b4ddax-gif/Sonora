package com.example.data.repository

import com.example.BuildConfig
import com.example.data.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class RecommendationResult(
    val explanation: String,
    val suggestedTrackIds: List<String>,
    val moodTitle: String,
    val isLiveAi: Boolean = true
)

class GeminiRecommendationRepository {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    // Can be overridden via Settings for development testing
    var customApiKey: String? = null

    fun hasApiKey(): Boolean {
        val key = getApiKey()
        return !key.isNullOrBlank() && key != "MY_GEMINI_API_KEY"
    }

    private fun getApiKey(): String? {
        val custom = customApiKey
        if (!custom.isNullOrBlank()) return custom
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isNotBlank() && key != "MY_GEMINI_API_KEY") key else null
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getRecommendations(
        moodOrPrompt: String,
        availableSongs: List<Song>,
        recentlyPlayed: List<Song>
    ): RecommendationResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()

        // Catalog overview for Gemini context
        val catalogInfo = availableSongs.joinToString("\n") {
            "- ID: ${it.id} | Title: ${it.title} | Artist: ${it.artist} | Genre: ${it.genre} | Album: ${it.album}"
        }

        val recentInfo = if (recentlyPlayed.isNotEmpty()) {
            recentlyPlayed.take(5).joinToString(", ") { "${it.title} by ${it.artist}" }
        } else {
            "None yet"
        }

        if (apiKey.isNullOrBlank()) {
            // Intelligent local fallback matching mood
            return@withContext generateLocalRecommendation(moodOrPrompt, availableSongs)
        }

        val systemPrompt = """
            You are SONORA AI, an expert music curator in the Sonora music player.
            You must recommend tracks from the available catalog strictly based on the user's mood or request.
            Do not claim access to third-party copyrighted tracks outside this catalog.
            
            Available catalog:
            $catalogInfo
            
            User's recent listening: $recentInfo
            
            Output strictly JSON matching this structure:
            {
              "moodTitle": "A catchy 2-4 word title for this vibe",
              "explanation": "1-2 brief sentences explaining why these songs fit the vibe",
              "trackIds": ["track_id_1", "track_id_2", ...]
            }
        """.trimIndent()

        val userMessage = "User request: $moodOrPrompt"

        val jsonBody = JSONObject().apply {
            val contentsArray = JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", "$systemPrompt\n\n$userMessage"))
                    })
                })
            }
            put("contents", contentsArray)

            val generationConfig = JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.7)
            }
            put("generationConfig", generationConfig)
        }

        try {
            val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(endpoint)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val responseString = response.body?.string() ?: ""
                val responseJson = JSONObject(responseString)
                val candidates = responseJson.optJSONArray("candidates")
                val text = candidates?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")

                if (!text.isNullOrBlank()) {
                    val parsed = JSONObject(text)
                    val moodTitle = parsed.optString("moodTitle", moodOrPrompt.capitalize())
                    val explanation = parsed.optString("explanation", "Curated especially for your session.")
                    val trackIdsJson = parsed.optJSONArray("trackIds")
                    val trackIds = mutableListOf<String>()
                    if (trackIdsJson != null) {
                        for (i in 0 until trackIdsJson.length()) {
                            trackIds.add(trackIdsJson.getString(i))
                        }
                    }
                    if (trackIds.isNotEmpty()) {
                        return@withContext RecommendationResult(
                            explanation = explanation,
                            suggestedTrackIds = trackIds,
                            moodTitle = moodTitle,
                            isLiveAi = true
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // Fallback gracefully on network or key issue
        }

        generateLocalRecommendation(moodOrPrompt, availableSongs)
    }

    private fun generateLocalRecommendation(mood: String, availableSongs: List<Song>): RecommendationResult {
        val lower = mood.lowercase()
        val (filtered, title, explanation) = when {
            lower.contains("focus") || lower.contains("study") || lower.contains("work") -> {
                Triple(
                    availableSongs.filter { it.genre in listOf("Ambient", "Lo-Fi", "Electronic") },
                    "Deep Focus Flow",
                    "Instrumental beats and calm ambient textures selected to enhance deep work."
                )
            }
            lower.contains("night") || lower.contains("drive") || lower.contains("neon") -> {
                Triple(
                    availableSongs.filter { it.genre in listOf("Synthwave", "Electronic") },
                    "Neon Nightscapes",
                    "Pulsing analog synthesizers and retro-wave rhythms tailored for late-night journeys."
                )
            }
            lower.contains("chill") || lower.contains("relax") || lower.contains("calm") -> {
                Triple(
                    availableSongs.filter { it.genre in listOf("Lo-Fi", "Indie", "Ambient") },
                    "Sunset Tranquility",
                    "Warm acoustic melodies and gentle grooves for mindful relaxation."
                )
            }
            lower.contains("energy") || lower.contains("workout") || lower.contains("run") -> {
                Triple(
                    availableSongs.filter { it.genre in listOf("Synthwave", "Electronic", "Indie") },
                    "High Energy Surge",
                    "Driving beats and uplifting momentum to fuel your momentum."
                )
            }
            else -> {
                Triple(
                    availableSongs.shuffled().take(4),
                    "Curated Discovery",
                    "A personalized blend of licensed tracks spanning relaxing and melodic soundscapes."
                )
            }
        }

        val trackIds = (if (filtered.isNotEmpty()) filtered else availableSongs.take(4)).map { it.id }
        return RecommendationResult(
            explanation = explanation,
            suggestedTrackIds = trackIds,
            moodTitle = title,
            isLiveAi = false
        )
    }
}
