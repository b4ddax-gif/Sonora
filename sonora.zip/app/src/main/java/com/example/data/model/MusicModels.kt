package com.example.data.model

import com.example.data.local.entity.AlbumEntity
import com.example.data.local.entity.ArtistEntity
import com.example.data.local.entity.DownloadedTrackEntity
import com.example.data.local.entity.PlaylistEntity
import com.example.data.local.entity.SongEntity

data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val audioUrl: String,
    val artworkUrl: String,
    val isLocal: Boolean = false,
    val isDownloaded: Boolean = false,
    val localFilePath: String? = null,
    val genre: String = "Pop",
    val year: Int = 2024,
    val isFavorite: Boolean = false
) {
    fun getEffectiveAudioUri(): String {
        return if (isDownloaded && !localFilePath.isNullOrBlank()) {
            localFilePath
        } else {
            audioUrl
        }
    }
}

data class Album(
    val id: String,
    val title: String,
    val artist: String,
    val artworkUrl: String,
    val songCount: Int = 0,
    val year: Int = 2024
)

data class Artist(
    val id: String,
    val name: String,
    val artworkUrl: String,
    val genre: String = "Various",
    val bio: String = ""
)

data class Playlist(
    val id: String,
    val title: String,
    val description: String = "",
    val artworkUrl: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val songCount: Int = 0
)

data class DownloadItem(
    val songId: String,
    val title: String,
    val artist: String,
    val artworkUrl: String,
    val progress: Int,
    val status: DownloadStatus,
    val fileSize: Long,
    val filePath: String
)

enum class DownloadStatus {
    PENDING,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED
}

enum class RepeatMode {
    OFF,
    ALL,
    ONE
}

enum class AudioQuality(val title: String, val bitRate: String) {
    NORMAL("Normal", "128 kbps"),
    HIGH("High", "256 kbps"),
    EXTREME("Extreme", "320 kbps"),
    LOSSLESS("Lossless", "FLAC 1411 kbps")
}

fun SongEntity.toSong(isFavorite: Boolean = false, isDownloaded: Boolean = false, localPath: String? = null): Song {
    return Song(
        id = id,
        title = title,
        artist = artist,
        album = album,
        durationMs = durationMs,
        audioUrl = audioUrl,
        artworkUrl = artworkUrl,
        isLocal = isLocal,
        isDownloaded = isDownloaded || this.isDownloaded,
        localFilePath = localPath ?: localFilePath,
        genre = genre,
        year = year,
        isFavorite = isFavorite
    )
}

fun Song.toEntity(): SongEntity {
    return SongEntity(
        id = id,
        title = title,
        artist = artist,
        album = album,
        durationMs = durationMs,
        audioUrl = audioUrl,
        artworkUrl = artworkUrl,
        isLocal = isLocal,
        isDownloaded = isDownloaded,
        localFilePath = localFilePath,
        genre = genre,
        year = year
    )
}

fun AlbumEntity.toAlbum(): Album = Album(id, title, artist, artworkUrl, songCount, year)
fun Album.toEntity(): AlbumEntity = AlbumEntity(id, title, artist, artworkUrl, songCount, year)

fun ArtistEntity.toArtist(): Artist = Artist(id, name, artworkUrl, genre, bio)
fun Artist.toEntity(): ArtistEntity = ArtistEntity(id, name, artworkUrl, genre, bio)

fun PlaylistEntity.toPlaylist(songCount: Int = 0): Playlist = Playlist(id, title, description, artworkUrl, createdAt, songCount)
fun Playlist.toEntity(): PlaylistEntity = PlaylistEntity(id, title, description, artworkUrl, createdAt)

fun DownloadedTrackEntity.toDownloadStatus(): DownloadStatus {
    return try {
        DownloadStatus.valueOf(status)
    } catch (e: Exception) {
        DownloadStatus.COMPLETED
    }
}
