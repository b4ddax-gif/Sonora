package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AudioQuality
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SonoraSettings(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("sonora_prefs", Context.MODE_PRIVATE)

    private val _themeMode = MutableStateFlow(prefs.getString("theme_mode", "dark") ?: "dark")
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _audioQuality = MutableStateFlow(
        AudioQuality.valueOf(prefs.getString("audio_quality", AudioQuality.HIGH.name) ?: AudioQuality.HIGH.name)
    )
    val audioQuality: StateFlow<AudioQuality> = _audioQuality.asStateFlow()

    private val _downloadQuality = MutableStateFlow(prefs.getString("download_quality", "High") ?: "High")
    val downloadQuality: StateFlow<String> = _downloadQuality.asStateFlow()

    private val _wifiOnlyDownloads = MutableStateFlow(prefs.getBoolean("wifi_only_dl", false))
    val wifiOnlyDownloads: StateFlow<Boolean> = _wifiOnlyDownloads.asStateFlow()

    private val _searchHistory = MutableStateFlow(
        prefs.getStringSet("search_history", emptySet())?.toList() ?: listOf("Synthwave", "Celeste River", "Deep Focus")
    )
    val searchHistory: StateFlow<List<String>> = _searchHistory.asStateFlow()

    fun setThemeMode(mode: String) {
        _themeMode.value = mode
        prefs.edit().putString("theme_mode", mode).apply()
    }

    fun setAudioQuality(quality: AudioQuality) {
        _audioQuality.value = quality
        prefs.edit().putString("audio_quality", quality.name).apply()
    }

    fun setDownloadQuality(quality: String) {
        _downloadQuality.value = quality
        prefs.edit().putString("download_quality", quality).apply()
    }

    fun setWifiOnlyDownloads(enabled: Boolean) {
        _wifiOnlyDownloads.value = enabled
        prefs.edit().putBoolean("wifi_only_dl", enabled).apply()
    }

    fun addSearchQuery(query: String) {
        val trimmed = query.trim()
        if (trimmed.isBlank()) return
        val current = _searchHistory.value.toMutableList()
        current.remove(trimmed)
        current.add(0, trimmed)
        val limited = current.take(15)
        _searchHistory.value = limited
        prefs.edit().putStringSet("search_history", limited.toSet()).apply()
    }

    fun removeSearchQuery(query: String) {
        val current = _searchHistory.value.toMutableList()
        current.remove(query)
        _searchHistory.value = current
        prefs.edit().putStringSet("search_history", current.toSet()).apply()
    }

    fun clearSearchHistory() {
        _searchHistory.value = emptyList()
        prefs.edit().remove("search_history").apply()
    }
}
