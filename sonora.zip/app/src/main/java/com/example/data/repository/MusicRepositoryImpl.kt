package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.FavoriteEntity
import com.example.data.local.entity.PlaylistEntity
import com.example.data.local.entity.PlaylistSongEntity
import com.example.data.local.entity.RecentlyPlayedEntity
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.Playlist
import com.example.data.model.Song
import com.example.data.model.toAlbum
import com.example.data.model.toArtist
import com.example.data.model.toEntity
import com.example.data.model.toPlaylist
import com.example.data.model.toSong
import com.example.data.sample.SampleMusicData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.UUID

class MusicRepositoryImpl(
    private val database: AppDatabase
) : MusicRepository {

    private val songDao = database.songDao()
    private val albumDao = database.albumDao()
    private val artistDao = database.artistDao()
    private val playlistDao = database.playlistDao()
    private val favoriteDao = database.favoriteDao()
    private val recentlyPlayedDao = database.recentlyPlayedDao()
    private val downloadedTrackDao = database.downloadedTrackDao()

    override fun getAllSongs(): Flow<List<Song>> {
        return combine(
            songDao.getAllSongs(),
            favoriteDao.getFavoriteSongIds(),
            downloadedTrackDao.getDownloadedSongIds()
        ) { songEntities, favIds, dlIds ->
            val favSet = favIds.toSet()
            val dlSet = dlIds.toSet()
            songEntities.map { entity ->
                entity.toSong(
                    isFavorite = favSet.contains(entity.id),
                    isDownloaded = dlSet.contains(entity.id)
                )
            }
        }.flowOn(Dispatchers.IO)
    }

    override fun getRecentlyPlayed(): Flow<List<Song>> {
        return combine(
            recentlyPlayedDao.getRecentlyPlayedSongs(),
            favoriteDao.getFavoriteSongIds(),
            downloadedTrackDao.getDownloadedSongIds()
        ) { songEntities, favIds, dlIds ->
            val favSet = favIds.toSet()
            val dlSet = dlIds.toSet()
            songEntities.map { entity ->
                entity.toSong(
                    isFavorite = favSet.contains(entity.id),
                    isDownloaded = dlSet.contains(entity.id)
                )
            }
        }.flowOn(Dispatchers.IO)
    }

    override fun getFavorites(): Flow<List<Song>> {
        return combine(
            favoriteDao.getFavoriteSongs(),
            downloadedTrackDao.getDownloadedSongIds()
        ) { songEntities, dlIds ->
            val dlSet = dlIds.toSet()
            songEntities.map { entity ->
                entity.toSong(
                    isFavorite = true,
                    isDownloaded = dlSet.contains(entity.id)
                )
            }
        }.flowOn(Dispatchers.IO)
    }

    override fun getDownloadedSongs(): Flow<List<Song>> {
        return combine(
            downloadedTrackDao.getDownloadedSongs(),
            favoriteDao.getFavoriteSongIds()
        ) { songEntities, favIds ->
            val favSet = favIds.toSet()
            songEntities.map { entity ->
                entity.toSong(
                    isFavorite = favSet.contains(entity.id),
                    isDownloaded = true
                )
            }
        }.flowOn(Dispatchers.IO)
    }

    override fun getLocalSongs(): Flow<List<Song>> {
        return combine(
            songDao.getLocalSongs(),
            favoriteDao.getFavoriteSongIds(),
            downloadedTrackDao.getDownloadedSongIds()
        ) { songEntities, favIds, dlIds ->
            val favSet = favIds.toSet()
            val dlSet = dlIds.toSet()
            songEntities.map { entity ->
                entity.toSong(
                    isFavorite = favSet.contains(entity.id),
                    isDownloaded = dlSet.contains(entity.id)
                )
            }
        }.flowOn(Dispatchers.IO)
    }

    override fun getAllPlaylists(): Flow<List<Playlist>> {
        return playlistDao.getAllPlaylists().map { entities ->
            entities.map { it.toPlaylist() }
        }.flowOn(Dispatchers.IO)
    }

    override fun getPlaylistWithSongs(playlistId: String): Flow<Pair<Playlist?, List<Song>>> {
        return combine(
            playlistDao.getPlaylistById(playlistId),
            playlistDao.getSongsForPlaylist(playlistId),
            favoriteDao.getFavoriteSongIds(),
            downloadedTrackDao.getDownloadedSongIds()
        ) { playlistEntity, songEntities, favIds, dlIds ->
            val favSet = favIds.toSet()
            val dlSet = dlIds.toSet()
            val songs = songEntities.map { entity ->
                entity.toSong(
                    isFavorite = favSet.contains(entity.id),
                    isDownloaded = dlSet.contains(entity.id)
                )
            }
            val playlist = playlistEntity?.toPlaylist(songCount = songs.size)
            Pair(playlist, songs)
        }.flowOn(Dispatchers.IO)
    }

    override fun getAllAlbums(): Flow<List<Album>> {
        return albumDao.getAllAlbums().map { entities ->
            entities.map { it.toAlbum() }
        }.flowOn(Dispatchers.IO)
    }

    override fun getAllArtists(): Flow<List<Artist>> {
        return artistDao.getAllArtists().map { entities ->
            entities.map { it.toArtist() }
        }.flowOn(Dispatchers.IO)
    }

    override fun search(query: String): Flow<List<Song>> {
        val trimmed = query.trim()
        return combine(
            songDao.searchSongs(trimmed),
            favoriteDao.getFavoriteSongIds(),
            downloadedTrackDao.getDownloadedSongIds()
        ) { songEntities, favIds, dlIds ->
            val favSet = favIds.toSet()
            val dlSet = dlIds.toSet()
            songEntities.map { entity ->
                entity.toSong(
                    isFavorite = favSet.contains(entity.id),
                    isDownloaded = dlSet.contains(entity.id)
                )
            }
        }.flowOn(Dispatchers.IO)
    }

    override fun isFavorite(songId: String): Flow<Boolean> {
        return favoriteDao.isFavorite(songId).flowOn(Dispatchers.IO)
    }

    override suspend fun toggleFavorite(songId: String) = withContext(Dispatchers.IO) {
        val isFav = favoriteDao.isFavorite(songId).firstOrNull() ?: false
        if (isFav) {
            favoriteDao.deleteFavorite(songId)
        } else {
            favoriteDao.insertFavorite(FavoriteEntity(songId = songId))
        }
    }

    override suspend fun recordRecentlyPlayed(songId: String) = withContext(Dispatchers.IO) {
        recentlyPlayedDao.insertRecentlyPlayed(
            RecentlyPlayedEntity(songId = songId, playedAt = System.currentTimeMillis())
        )
    }

    override suspend fun createPlaylist(title: String, description: String): String = withContext(Dispatchers.IO) {
        val id = "playlist_" + UUID.randomUUID().toString().take(8)
        val defaultArtwork = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80"
        val playlist = PlaylistEntity(
            id = id,
            title = title,
            description = description,
            artworkUrl = defaultArtwork
        )
        playlistDao.insertPlaylist(playlist)
        id
    }

    override suspend fun renamePlaylist(playlistId: String, newTitle: String) = withContext(Dispatchers.IO) {
        val existing = playlistDao.getPlaylistById(playlistId).firstOrNull()
        if (existing != null) {
            playlistDao.updatePlaylist(existing.copy(title = newTitle))
        }
    }

    override suspend fun deletePlaylist(playlistId: String) = withContext(Dispatchers.IO) {
        playlistDao.deletePlaylistAndSongs(playlistId)
    }

    override suspend fun addSongToPlaylist(playlistId: String, songId: String) = withContext(Dispatchers.IO) {
        val existingSongs = playlistDao.getSongsForPlaylist(playlistId).firstOrNull() ?: emptyList()
        val orderIndex = existingSongs.size
        playlistDao.addSongToPlaylist(PlaylistSongEntity(playlistId, songId, orderIndex))
    }

    override suspend fun removeSongFromPlaylist(playlistId: String, songId: String) = withContext(Dispatchers.IO) {
        playlistDao.removeSongFromPlaylist(playlistId, songId)
    }

    override suspend fun importLocalSongs(songs: List<Song>) = withContext(Dispatchers.IO) {
        val entities = songs.map { it.toEntity() }
        songDao.insertSongs(entities)
    }

    override suspend fun initializeSampleDataIfNeeded() = withContext(Dispatchers.IO) {
        val count = songDao.getAllSongs().firstOrNull()?.size ?: 0
        if (count == 0) {
            songDao.insertSongs(SampleMusicData.songs)
            albumDao.insertAlbums(SampleMusicData.albums)
            artistDao.insertArtists(SampleMusicData.artists)
            SampleMusicData.playlists.forEach { playlistDao.insertPlaylist(it) }
            SampleMusicData.playlistSongs.forEach { playlistDao.addSongToPlaylist(it) }
            // Seed a couple favorites
            favoriteDao.insertFavorite(FavoriteEntity("track_in_1"))
            favoriteDao.insertFavorite(FavoriteEntity("track_1"))
            // Seed recently played
            recentlyPlayedDao.insertRecentlyPlayed(RecentlyPlayedEntity("track_in_1", System.currentTimeMillis() - 600000))
            recentlyPlayedDao.insertRecentlyPlayed(RecentlyPlayedEntity("track_1", System.currentTimeMillis() - 300000))
        } else {
            // Guarantee "All Indian Songs" playlist and its tracks exist even for existing databases
            val existingIndianPlaylist = playlistDao.getPlaylistById("playlist_indian").firstOrNull()
            if (existingIndianPlaylist == null) {
                songDao.insertSongs(SampleMusicData.indianSongs)
                albumDao.insertAlbums(SampleMusicData.indianAlbums)
                artistDao.insertArtists(SampleMusicData.indianArtists)
                playlistDao.insertPlaylist(SampleMusicData.indianPlaylist)
                SampleMusicData.indianPlaylistSongs.forEach { playlistDao.addSongToPlaylist(it) }
            }
        }
    }
}
