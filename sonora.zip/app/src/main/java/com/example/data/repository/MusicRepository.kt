package com.example.data.repository

import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.Playlist
import com.example.data.model.Song
import kotlinx.coroutines.flow.Flow

interface MusicRepository {
    fun getAllSongs(): Flow<List<Song>>
    fun getRecentlyPlayed(): Flow<List<Song>>
    fun getFavorites(): Flow<List<Song>>
    fun getDownloadedSongs(): Flow<List<Song>>
    fun getLocalSongs(): Flow<List<Song>>
    fun getAllPlaylists(): Flow<List<Playlist>>
    fun getPlaylistWithSongs(playlistId: String): Flow<Pair<Playlist?, List<Song>>>
    fun getAllAlbums(): Flow<List<Album>>
    fun getAllArtists(): Flow<List<Artist>>
    fun search(query: String): Flow<List<Song>>
    fun isFavorite(songId: String): Flow<Boolean>

    suspend fun toggleFavorite(songId: String)
    suspend fun recordRecentlyPlayed(songId: String)
    suspend fun createPlaylist(title: String, description: String = ""): String
    suspend fun renamePlaylist(playlistId: String, newTitle: String)
    suspend fun deletePlaylist(playlistId: String)
    suspend fun addSongToPlaylist(playlistId: String, songId: String)
    suspend fun removeSongFromPlaylist(playlistId: String, songId: String)
    suspend fun importLocalSongs(songs: List<Song>)
    suspend fun initializeSampleDataIfNeeded()
}
