package com.example

import com.example.ui.util.FormatUtils
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun timeFormatting_isCorrect() {
        assertEquals("0:00", FormatUtils.formatDuration(0L))
        assertEquals("1:05", FormatUtils.formatDuration(65_000L))
        assertEquals("3:45", FormatUtils.formatDuration(225_000L))
        assertEquals("1:01:05", FormatUtils.formatDuration(3665_000L))
    }

    @Test
    fun fileSizeFormatting_isCorrect() {
        assertEquals("0 B", FormatUtils.formatFileSize(0L))
        assertEquals("500 B", FormatUtils.formatFileSize(500L))
        assertEquals("1.0 MB", FormatUtils.formatFileSize(1024 * 1024L))
        assertEquals("8.5 MB", FormatUtils.formatFileSize((8.5 * 1024 * 1024).toLong()))
    }

    @Test
    fun indianPlaylist_containsExpectedTracks() {
        val playlist = com.example.data.sample.SampleMusicData.indianPlaylist
        assertEquals("All Indian Songs", playlist.title)
        val songs = com.example.data.sample.SampleMusicData.indianSongs
        org.junit.Assert.assertTrue(songs.isNotEmpty())
        org.junit.Assert.assertTrue(songs.any { it.title.contains("Kesariya") })
        org.junit.Assert.assertTrue(songs.any { it.genre == "Indian Classical" })
    }
}
