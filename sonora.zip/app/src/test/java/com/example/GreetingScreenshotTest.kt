package com.example

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.unit.dp
import com.example.data.sample.SampleMusicData
import com.example.ui.components.SongItemRow
import com.example.ui.theme.SonoraTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun sonora_song_item_screenshot() {
        val sampleSong = SampleMusicData.SAMPLE_SONGS.first()
        composeTestRule.setContent {
            SonoraTheme {
                Box(modifier = Modifier.padding(16.dp)) {
                    SongItemRow(
                        song = sampleSong,
                        isPlaying = true,
                        onClick = {},
                        onToggleFavorite = {},
                        onAddToQueue = {},
                        onAddToPlaylist = {},
                        onDownload = {},
                        onDeleteDownload = {}
                    )
                }
            }
        }

        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
    }
}
