package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.DownloadRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context verifies SONORA app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SONORA", appName)
    }

    @Test
    fun `youtube download guardrail blocks all youtube urls`() {
        assertTrue(DownloadRepository.isYouTubeUrl("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
        assertTrue(DownloadRepository.isYouTubeUrl("https://youtu.be/dQw4w9WgXcQ"))
        assertTrue(DownloadRepository.isYouTubeUrl("https://music.youtube.com/watch?v=123"))
        assertFalse(DownloadRepository.isYouTubeUrl("https://commons.wikimedia.org/audio/track.mp3"))
        assertFalse(DownloadRepository.isYouTubeUrl("https://archive.org/details/mysong.mp3"))
    }

    @Test
    fun `audio permission helper selects READ_MEDIA_AUDIO on modern Android`() {
        val perm = com.example.ui.util.LocalAudioScannerHelper.requiredAudioPermission
        assertEquals(android.Manifest.permission.READ_MEDIA_AUDIO, perm)
    }
}
